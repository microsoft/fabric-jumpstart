import os
import tempfile
import shutil

from fabric_jumpstart.utils import download_file, set_workspace_in_yml

SETUP_URL = (
    "https://github.com/microsoft/fabric-toolbox/raw/main/monitoring/fabric-spark-monitoring/setup/fabric-spark-monitoring-setup.ipynb"
)

def install(workspace_name: str, environment: str = "N/A", **kwargs):
    from fabric_cicd import append_feature_flag, deploy_with_config

    # Enable required flags for config-driven deploys
    append_feature_flag("enable_experimental_features")
    append_feature_flag("enable_config_deploy")

    print("[spark_rti_monitoring] Preparing deployment folder...")
    with tempfile.TemporaryDirectory() as staging:
        # Download notebook
        nb_name = "fabric-spark-monitoring-setup.ipynb"
        local_nb = os.path.join(staging, nb_name)
        download_file(SETUP_URL, local_nb)

        # Copy YAML template to staging and update workspace
        yml_src = os.path.join(os.path.dirname(__file__), "../yml_templates/spark_rti_monitoring.yml")
        yml_dst = os.path.join(staging, "spark_rti_monitoring.yml")
        shutil.copyfile(yml_src, yml_dst)
        set_workspace_in_yml(yml_dst, workspace_name)

        print("[spark_rti_monitoring] Deploying notebook with fabric_cicd.deploy_with_config...")
        deploy_with_config(
            config_file_path=yml_dst,
            environment=environment
        )

    print(f"[spark_rti_monitoring] Demo notebook deployed to workspace '{workspace_name}'. Go to Fabric and run it to finish setup.")