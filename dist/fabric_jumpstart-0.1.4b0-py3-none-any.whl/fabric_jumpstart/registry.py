KNOWN_DEMOS = {
    "spark-rti-monitoring": {
        "title": "Spark Monitoring Excellence",
        "description": "Deploys all resources for Spark RTI Monitoring demo.",
        "yml": "spark_rti_monitoring.yml",
        "py_mod": "fabric_jumpstart.demos.spark_rti_monitoring"
    },
    # Add more demos here
}