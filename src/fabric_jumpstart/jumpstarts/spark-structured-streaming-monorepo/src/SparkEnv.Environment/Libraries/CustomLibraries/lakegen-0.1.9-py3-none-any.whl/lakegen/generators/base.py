from abc import ABC
import fsspec
import time

class BaseGenerator(ABC):
    
    def __init__(self, target_folder_uri: str):
        self.target_folder_uri = target_folder_uri
        self.fs, self.__fs_path = fsspec.core.url_to_fs(target_folder_uri)

        self._original_rm = self.fs.rm
        self.fs.rm = self._rm_with_retry

    def _rm_with_retry(self, path, **kwargs):
        """Wrapper for fs.rm() that retries up to 2 times upon failure due to ADLSg2 recursive delete issues."""
        max_retries = 2
        last_exception = None

        for attempt in range(max_retries + 1):
            try:
                return self._original_rm(path, **kwargs)
            except Exception as e:
                last_exception = e
                if attempt < max_retries:
                    wait_time = (attempt + 1) * 0.5  # 0.5s, 1s
                    # print(f"[Retry {attempt + 1}/{max_retries}] fs.rm() failed: {e}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)

        raise last_exception