import faker

class Customer:
    def __init__(self):
        self.faker = faker.Faker()
        
    def _generate_customer(self, seed=1):
        self.faker.seed_instance(seed)
        customer = {
            "CustomerId": str(self.faker.uuid4()),
            "CustomerName": self.faker.company(),
            "Description": self.faker.catch_phrase(),
            "PrimaryContactFirstName": self.faker.first_name(),
            "PrimaryContactLastName": self.faker.last_name(),
            "PrimaryContactEmail": self.faker.email(),
            "PrimaryContactPhone": self.faker.phone_number(),
            "DeliveryAddress": {
                "Address": self.faker.street_address(),
                "City": self.faker.city(),
                "State": self.faker.state_abbr(),
                "ZipCode": self.faker.postcode(),
                "Country": "USA",
                "Latitude": float(self.faker.latitude()),
                "Longitude": float(self.faker.longitude())
            },
            "BillingAddress": {
                "Address": self.faker.street_address(),
                "City": self.faker.city(),
                "State": self.faker.state_abbr(),
                "ZipCode": self.faker.postcode(),
                "Country": "USA"
            }
        }
        return customer