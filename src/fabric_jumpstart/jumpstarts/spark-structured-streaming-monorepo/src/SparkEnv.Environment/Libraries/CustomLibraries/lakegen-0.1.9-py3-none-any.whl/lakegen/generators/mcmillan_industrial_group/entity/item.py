import random
import uuid
import numpy as np

class Item:
    def __init__(self):
        # Inspired by Patriot, the TV Show.
        # https://www.youtube.com/watch?v=P5-9Rfrui9A
        # https://www.youtube.com/watch?v=-F-IHvF5OCA&t=4s

        self.brands = [
            "McMillan Engineering",
            "Claret Solutions",
            "DynaStruct",
            "SplayFlex",
            "VertiFlex",
            "Praxidyne",
            "JoistMaster",
            "HatchTech",
            "FlowCore",
            "TriSpan",
            "DramLine",
            "Donnely Precision"
        ]

        self.category_item_map = {
            "Flow": [
                "Alignment Sleeve", "Grip Coupler", "Flow Regulator", "Hatch Coupler",
                "Dampener", "S.K.N. Coupler", "Chim Line Adapter",
                "Transport Coupler", "Flow Index Collar",
            ],
            "Structural": [
                "Spurv Plinth", "Plate Module", "Joust Jamb", "Rim-Riding Grip Plate",
                "Brace Column", "Brace Plate", "Prasm Stabilizer",
                "Jim Joist", "Patch Hampler", "Girdle Jerry",
                "Plate Flex Tandem", "Spram Shaft", "Donnely Spacing Grid", "Nut Plate",
                "Maiden Clamp Plate", "Jim Joust"
            ],
            "Drainage": [
                "Pan Trap", "Drain Hampler", "Splay Valve", "Residue Transport Baffle", "Plate Funnel",
                "Vent Dampener"
            ],
            "Instrumentation": [
                "Depth Indicator", "Flow Index Probe", "Insinuator Module", 
                "Transport Meter", "Resonance Monitor", "Span Fixture Module", "Flow Index Collar", "Spram Actuator"
            ],
            "Misc. Components": [
                "Half-C Sprat", "T-Nut", "Husk Nut", "Nut Spacer", "Spram Knuckle", "Hatch Flap", "Gauge Assay",
                "Transport Flap", "Tri-Pin", "Hauser", "Damper Crown",
                "Bracket Cap", "Crown Ring", "Heat Rail", "Task Apparatus", "Junction Flange", "Housing Assembly",
                "Nickel Slit", "Hatch Depth Ring", "Donnely Nut", "Donnely Nut Spacer"
            ]
        }

        self.materials = [
            # Carbon & Low Alloy Steels
            "A36",
            "A105",
            "A106 Grade B",
            "A516 Grade 70",
            "4130",
            "4140",
            "4340",
        
            # Stainless Steels (Austenitic)
            "304",
            "304L",
            "316",
            "316L",
            "321",
            "347",
        
            # Stainless Steels (Martensitic / Ferritic)
            "410",
            "420",
            "430",
            "440C",
        
            # Duplex / Super Duplex
            "Duplex 2205",
            "Super Duplex 2507",
        
            # Nickel & High Temp Alloys
            "Inconel 600",
            "Inconel 625",
            "Inconel 718",
            "Hastelloy C-276",
            "Hastelloy B-2",
            "Monel 400",
            "Nickel 200",
            "Incoloy 800H",
        
            # Copper & Bronze
            "C260 Brass",
            "C360 Brass",
            "C95400 Aluminum Bronze",
            "C93200 Bearing Bronze",
            "CuNi 90/10",
            "CuNi 70/30",
        
            # Titanium
            "Titanium Grade 2",
            "Titanium Grade 5",
        
            # Ductile / Cast Iron
            "Ductile Iron 65-45-12",
            "Ductile Iron 80-55-06",
            "Gray Iron Class 40",
        
            # Aluminum Alloys
            "6061-T6",
            "6063",
            "7075-T6"
        ]

        self.end_connections = [
            "Buttweld", "Socket Weld", "NPT", "NPS", "BSPT", "BSPP", "MNPT", "Flanged", "FNPT",
            "Grooved", "Flanged RF", "Flanged FF", "Press-Fit", "Victaulic", "Camlock", "Quick-Connect",
            "Tri-Clamp", "Flanged Weld Neck", "Flanged Slip-On", "Bevel-End", "Plain-End",
            "Blind Flange", "Lap-Joint Flange", "Threaded Flange", "Weld Neck Flange", "Ferrule Clamp"
        ]

        self.pressure_classes = [150, 300, 600, 900, 1500, 2500]

        self.jargon_things = [item for sublist in self.category_item_map.values() for item in sublist]

        self.jargon_adjectives = [
            "structural",
            "thermal",
            "mechanical",
            "vibrational",
            "torsional",
            "lateral",
            "axial",
            "radial",
            "hydraulic",
            "pneumatic",
            "corrosional",
            "vibrational",
            "transversal",
            "longitudinal",
            "operational",
            "computational",
            "dimensional",
            "rotational",
            "directional",
            "functional",
            "residual",
            "thermal-cyclical",
            'cylindrical',
            'conical',
        ]

        self.jargon_adverbs = [f"{adj}ally" if adj.endswith("ic") else f"{adj}ly" for adj in self.jargon_adjectives]

        self.negative_nouns = [
            'tension',
            'debris',
            'sediment',
            'constriction',
            'pressure',
            'load',
            'stress',
            'strain',
            'shear',
            'torsion',
            "displacement",
            "slippage",
            "resistance",
            "fatigue",
            "expansion",
            "buckling"
        ]

        self.positive_nouns = [
            'flow',
            'support',
            'alignment',
            'stability',
            'efficiency',
            'integrity',
            'distribution',
            'dampening',
            'attenuation',
            'flexing',
            'resilience'
            ]

        self.gerunds = [
            'aligning',
            'dampening',
            'distributing',
            'expanding',
            'flexing',
            'deflecting',
            'compressing',
            'sequencing',
            'stabilizing',
            'alternating'
        ]

        self.modifiers = [
            "double", "triple", "layered", "stacked", "paired", "vertically composited", 
            "reinforced", "pressed", "beam-fastened", "brass-fitted", "conjoined",
            "splay-flexed", "pin flam-fastened", "vertipin-plated", "puncher-plated", "husked",
            "alternating", "sequencing", "funneling", "dampening"
        ]

        self.nominal_sizes = sorted({
            0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 8,
            10, 12, 14, 16, 18, 20, 24, 30, 36, 42, 48
        })


    # ---------------------------------------------------------
    # Helpers  
    # ---------------------------------------------------------
    def _brand_prefix(self, brand: str) -> str:
        return brand[:2].upper()
    
    def _make_concept(self, thing, type):
        adj = random.choice(self.jargon_adjectives)
        if type == "positive":
            noun = random.choice(self.positive_nouns)
        else:
            noun = random.choice(self.negative_nouns)
        if random.random() < 0.75:
            if random.random() < 0.60:
                return f"{adj} {thing} {noun}"
            else:
                return f"{adj} {noun} of the {thing}"
        else:
            return f"{adj} {noun}"
    
    def _plural(self, term: str) -> str:
        # very light pluralization so "half-C sprats" reads okay
        if term.endswith("s"):
            pluralized = term
        elif term.endswith("y") and not term.endswith("ey"):
            pluralized = term[:-1] + "ies"
        elif term.endswith("x"):
            pluralized = term + "es"
        else:
            pluralized = term + "s"
        
        return pluralized
    
    def _modifier(self, term: str) -> int:
        # Sometimes add a multiplier
        multiplier_type = random.choice(["quantity", "size", "word"])
        if multiplier_type == "quantity":
            # Even number between 2 and 12
            num = random.choice([2, 4, 6, 8, 10, 12])
            return f"{num} {term}"
        elif multiplier_type == "size":
            # Size modifier
            size = random.choice(self.nominal_sizes)
            return f"{size}\" {term}"
        else:
            # modifier
            word = random.choice(self.modifiers)
            return f"{word} {term}"
    
    def _generate_description(self, size, subcat):
        # Choose a thing that's different from subcat
        available_things = [t for t in self.jargon_things if t != subcat]
        things = [thing.lower() for thing in random.sample(available_things, 6)]
        thing = things[0]
        thing_plural = self._plural(thing)
        thing_plural_modified = self._modifier(thing_plural)

        thing2 = things[1]
        thing2_plural = self._plural(thing2)
        thing2_plural_modified = self._modifier(thing2_plural)

        thing3 = things[2]
        thing3_plural = self._plural(thing3)
        thing3_plural_modified = self._modifier(thing3_plural)

        positive_concept = self._make_concept(things[3], "positive")
        positive_concept2 = self._make_concept(things[4], "positive")
        negative_concept = self._make_concept(things[3], "negative")

        # Templates that start with verbs (no connector needed)
        verb_templates = [
            f'engineered to mitigate {negative_concept} in high-flow systems utilizing {random.choice(self.modifiers)} {things[5]} assemblies.',
            f'features integrated {thing_plural_modified} providing enhanced {positive_concept} under operating conditions.',
            f'manufactured with {random.choice(self.modifiers)} {thing} interface for {random.choice(self.jargon_adverbs)}-controlled {negative_concept} management.',
            f'uses a field-proven design for installations requiring {negative_concept} regulation in proximity to {thing_plural}.',
            f'maintains consistent {random.choice([negative_concept, positive_concept])} parameters throughout {thing} operating envelope.',
            f'incorporates factory-installed {random.choice(self.modifiers)} {thing_plural} to deliver superior {positive_concept} performance.',
            f'constructed with {random.choice(self.modifiers)} {thing_plural} enabling precise {negative_concept} control and monitoring.',
            f'recommended for applications where {negative_concept} reduction is achieved through {thing_plural} interfacing.',
            f'fabricated with {thing_plural_modified} specifically engineered to address {negative_concept} in demanding environments.',
            f'is suitable for {random.choice(self.jargon_adjectives)} and {random.choice(self.jargon_adjectives)} service applications per ASME standards.',
        ]
        
        # Templates that are noun phrases or adjectives (need "is" or "is a")
        noun_templates = [
            f'precision-machined component optimizing {positive_concept} in {random.choice(self.modifiers)} {thing} installations.',
            f'critical application component where {negative_concept} control of {random.choice(self.modifiers)} {thing} must be maintained within specifications.',
            f'specialized component ensuring {positive_concept} compliance across {random.choice(self.modifiers)} {thing2_plural} configurations.',
            f'general-purpose solution for {positive_concept} optimization where integrating {thing_plural}.',
        ]

        add_on_templates = [
            f'{positive_concept2} is {random.choice(self.jargon_adverbs)} guaranteed via {thing2_plural_modified}.',
            f'required when {positive_concept2} is required.',
            f'often paired with {thing3_plural_modified}.',
            f'designed to work seamlessly with {thing3_plural}.',
            f'perfect for systems needing {positive_concept2}.',
            f'featuring {thing3_plural_modified}.',
            f'with {thing3_plural_modified}.',
            f'{thing3_plural_modified} NOT included.',
            f'requires regular maintenance of provided {thing2_plural_modified} for proper operation.'
        ]

        # Choose template type and apply appropriate connector
        if random.random() < 0.65:  # 65% verb templates
            description1 = random.choice(verb_templates)
            connector = ' '
        else:  # 35% noun templates
            description1 = random.choice(noun_templates)
            connector = random.choice([' is a ', ': ', ' - '])
        
        description2 = random.choice(add_on_templates)
        
        if random.random() < 0.3:
            description = f'{size}" {subcat}{connector}{description1} {description2[0].upper() + description2[1:]}'
        elif random.random() < 0.25:
            description = f'{size}" {subcat}. {description2[0].upper() + description2[1:]} {description1[0].upper() + description1[1:]}'
        else:
            description = f'{size}" {subcat}{connector}{description1}'

        return description


    def _subcat_code(self, subcat: str) -> str:
        return ''.join(subcat.split())[:3].upper()

    def generate_items(self, count=1000):
        items = []

        for i in range(1, count + 1):
            id = uuid.uuid4()
            item_number = id.int & 0xFFFFFFF
            brand = random.choices(
                self.brands,
                weights=[25, 10, 12, 10, 8, 8, 7, 6, 5, 4, 3, 2],  # McMillian most common
                k=1
            )[0]

            prefix = self._brand_prefix(brand)

            category = random.choices(
                list(self.category_item_map.keys()),
                weights=[30, 35, 10, 15, 20],  # Structural most common
                k=1
            )[0]

            subcat = random.choice(self.category_item_map[category])
            material = random.choices(
                self.materials,
                weights=[15, 12, 20, 10] + [1] * (len(self.materials) - 4),  # A106, 304, 316 most common
                k=1
            )[0]

            size = float(random.choices(
                self.nominal_sizes,
                weights=[20, 18, 16, 14, 12, 10, 8, 7, 6, 5] + [1] * (len(self.nominal_sizes) - 10),
                k=1
            )[0])

            # Skewed end connection - common types appear more
            weight = round(np.random.lognormal(mean=4, sigma=.7), 2)
            end_conn = random.choices(
                self.end_connections,
                weights=[25, 20, 15, 12, 10, 8] + [1] * (len(self.end_connections) - 6),
                k=1
            )[0]

            # Weighted pressure class - 150 and 300 most common
            pressure_class = random.choices(
                self.pressure_classes,
                weights=[40, 30, 15, 8, 5, 2],
                k=1
            )[0]

            desc = self._generate_description(size, subcat)
            code = f"{prefix}-{size}-{self._subcat_code(subcat)}-{item_number:09d}"

            cost = float(round(np.random.lognormal(mean=5, sigma=.9), 2))
            list_price = float(round(cost * random.uniform(1.2, 1.8), 2))
            is_sdof_certified = "Y" if random.random() < 0.7 else "N"
            structural_index = round(np.random.beta(a=5, b=1), 4)
            span_rating = round(np.random.exponential(scale=30), 1)

            items.append(
                {
                    "ItemId": str(id),
                    "SKU": code,
                    "Description": desc,
                    "Brand": brand,
                    "Category": category,
                    "Subcategory": subcat,
                    "Material": material,
                    "NominalSize": size,
                    "EndConnection": end_conn,
                    "PressureClass": pressure_class,
                    "Weight": weight,
                    "Cost": cost,
                    "ListPrice": list_price,
                    "IsSDOFCertified": is_sdof_certified,
                    "StructuralIndex": structural_index,
                    "SpanRating": span_rating
                }
            )

        return items
