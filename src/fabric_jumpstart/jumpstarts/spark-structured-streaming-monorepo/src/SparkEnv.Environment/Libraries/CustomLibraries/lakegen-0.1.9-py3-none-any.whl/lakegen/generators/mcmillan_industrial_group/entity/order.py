import faker
import random
import uuid

class Order:
    def __init__(self):
        self.faker = faker.Faker()
        
    def _generate_order(self, customer, item_catalog: list):
        id = uuid.uuid4()
        order_number = id.int & 0xFFFFFFFFFFFFFFFF

        order = {
            "OrderId": str(id),
            "OrderNumber": f"SO{order_number}",
            "OrderDate": self.faker.date_this_year().isoformat(),
            "OrderTotal": round(random.uniform(100, 10000), 2),
            "Source": random.choice(["Email", "Web", "Phone"]),
            "CustomerId": customer['CustomerId']
        }
        order_lines = []
        for i in range(1, random.randint(1, 10) + 1):
            item = random.choice(item_catalog)
            quantity = random.randint(1, 20)
            order_line = {
                "LineNumber": i,
                "ItemId": item['ItemId'],
                "SKU": item['SKU'],
                "Description": item['Description'],
                "NetWeight": quantity * item['Weight'],
                "Quantity": quantity,
                "UnitPrice": item['ListPrice'],
                "ExtendedPrice": round(item['ListPrice'] * quantity, 2),
                "WarrantyIncluded": random.choices([True, False], weights=[0.8, 0.2])[0]
            }
            order_lines.append(order_line)
        order['OrderLines'] = order_lines

        return order