from typing import Optional
import uuid
import random
import re
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from faker import Faker
import random
from datetime import datetime

from .shipment_lookups import *

# Initialize Faker
fake = Faker()

# Delivery Feedback
import re, random


class Shipment:
    def __init__(self, seed: Optional[int] = None):
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)


    def __init__(self):
        pass

    def __get_random_coordinate_near(self, lat, lng, radius_miles=10):
        """Generate a random coordinate near a point within specified radius in miles"""
        # 1 degree of latitude is approximately 69 miles
        # 1 degree of longitude varies but at equator is also approximately 69 miles
        radius_lat_deg = radius_miles / 69.0
        radius_lng_deg = radius_miles / (69.0 * np.cos(np.radians(lat)))
        
        random_lat = lat + random.uniform(-radius_lat_deg, radius_lat_deg)
        random_lng = lng + random.uniform(-radius_lng_deg, radius_lng_deg)
        
        return random_lat, random_lng

    def __generate_address_near_facility(self, facility, is_business=False):
        """Generate a realistic address near a facility"""
        lat, lng = self.__get_random_coordinate_near(facility["Latitude"], facility["Longitude"])
        
        if is_business:
            street = fake.street_address() + ", " + fake.company()
        else:
            street = fake.street_address()
        
        return {
            "Address": street,
            "City": facility["City"],
            "State": facility["State"],
            "ZipCode": facility["ZipCode"],
            "Country": "USA",
            "Latitude": lat,
            "Longitude": lng
        }

    def __select_random_weighted(self, options, weight_key="weight"):
        """Select an item randomly with weights"""
        weights = [item[weight_key] for item in options]
        total = sum(weights)
        normalized_weights = [w/total for w in weights]
        return np.random.choice(options, p=normalized_weights)

    def __get_commits(self, service_level, distance_miles):
        """Calculate committed delivery times based on service level and distance"""
        base_days = next((s["days"] for s in SERVICE_LEVELS if s["level"] == service_level), 4)
        
        # Adjust based on distance
        if distance_miles < 500:
            days_adjustment = -0.5
        elif distance_miles > 2000:
            days_adjustment = 1
        else:
            days_adjustment = 0
            
        return max(1, base_days + days_adjustment)

    def __haversine_distance(self, lat1, lon1, lat2, lon2):
        """Calculate the great circle distance between two points in miles"""
        lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        miles = 3959 * c  # Radius of earth in miles
        return miles

    def __find_closest_facility(self, lat, lng, facility_type=None):
        """Find the closest facility to a given coordinate"""
        facilities_to_check = FACILITIES
        if facility_type:
            facilities_to_check = [f for f in FACILITIES if f["FacilityType"] == facility_type]
            
        closest = None
        min_distance = float('inf')
        
        for facility in facilities_to_check:
            distance = self.__haversine_distance(lat, lng, facility["Latitude"], facility["Longitude"])
            if distance < min_distance:
                min_distance = distance
                closest = facility
        
        return closest, min_distance

    def __find_optimal_path(self, origin_facility_id, dest_facility_id):
        """Find a reasonable path from origin to destination"""
        # This is a simplified routing algorithm
        # In a real system, this would use graph algorithms like Dijkstra's
        
        origin_facility = next((f for f in FACILITIES if f["FacilityId"] == origin_facility_id), None)
        dest_facility = next((f for f in FACILITIES if f["FacilityId"] == dest_facility_id), None)
        
        if not origin_facility or not dest_facility:
            return []
        
        # Direct route if available
        key = f"{origin_facility_id}_{dest_facility_id}"
        if key in route_lookup:
            return [{"facility": origin_facility_id, "next": dest_facility_id, "route": route_lookup[key]}]
        
        # Try to route via hubs based on region
        path = []
        current = origin_facility_id
        
        # Step 1: If origin is local, try to route to nearest hub
        if origin_facility["FacilityType"] == "Local":
            # Find nearest hub
            hub_facilities = [f for f in FACILITIES if f["FacilityType"] == "Hub"]
            nearest_hub = min(hub_facilities, key=lambda h: 
                               self.__haversine_distance(origin_facility["Latitude"], origin_facility["Longitude"], 
                                          h["Latitude"], h["Longitude"]))
            key = f"{current}_{nearest_hub['FacilityId']}"
            if key in route_lookup:
                path.append({"facility": current, "next": nearest_hub["FacilityId"], "route": route_lookup[key]})
                current = nearest_hub["FacilityId"]
        
        # Step 2: If destination is local, find route to nearest hub
        if dest_facility["FacilityType"] == "Local":
            hub_facilities = [f for f in FACILITIES if f["FacilityType"] == "Hub"]
            nearest_dest_hub = min(hub_facilities, key=lambda h: 
                                  self.__haversine_distance(dest_facility["Latitude"], dest_facility["Longitude"], 
                                             h["Latitude"], h["Longitude"]))
            
            # Try to go from current to this hub
            key = f"{current}_{nearest_dest_hub['FacilityId']}"
            if key in route_lookup:
                path.append({"facility": current, "next": nearest_dest_hub["FacilityId"], "route": route_lookup[key]})
                current = nearest_dest_hub["FacilityId"]
            
            # Then from this hub to destination
            key = f"{current}_{dest_facility_id}"
            if key in route_lookup:
                path.append({"facility": current, "next": dest_facility_id, "route": route_lookup[key]})
                return path
        
        # Step 3: If still no path, try to use distribution centers
        if not path:
            # Find distribution centers near origin and destination
            dist_facilities = [f for f in FACILITIES if f["FacilityType"] == "Distribution"]
            if dist_facilities:
                nearest_origin_dc = min(dist_facilities, key=lambda d: 
                                      self.__haversine_distance(origin_facility["Latitude"], origin_facility["Longitude"], 
                                                 d["Latitude"], d["Longitude"]))
                nearest_dest_dc = min(dist_facilities, key=lambda d: 
                                     self.__haversine_distance(dest_facility["Latitude"], dest_facility["Longitude"], 
                                                d["Latitude"], d["Longitude"]))
                
                # Origin to DC
                key = f"{origin_facility_id}_{nearest_origin_dc['FacilityId']}"
                if key in route_lookup:
                    path.append({"facility": origin_facility_id, "next": nearest_origin_dc["FacilityId"], "route": route_lookup[key]})
                    current = nearest_origin_dc["FacilityId"]
                
                # DC to DC if needed
                key = f"{current}_{nearest_dest_dc['FacilityId']}"
                if current != nearest_dest_dc["FacilityId"] and key in route_lookup:
                    path.append({"facility": current, "next": nearest_dest_dc["FacilityId"], "route": route_lookup[key]})
                    current = nearest_dest_dc["FacilityId"]
                
                # DC to destination
                key = f"{current}_{dest_facility_id}"
                if key in route_lookup:
                    path.append({"facility": current, "next": dest_facility_id, "route": route_lookup[key]})
                    return path
        
        return path

    def __jitter_text(self, text: str, stars: int) -> str:
        cfg = JITTER[stars]
        out = text
        # "VERY late" emphasis for low stars
        if stars <= 2 and random.random() < 0.35:
            out = re.sub(r"\blate\b", "VERY late", out, flags=re.I)
        # Typos
        for pat, variants in TYPO_PATTERNS:
            if random.random() < cfg["typo_p"]:
                out = pat.sub(random.choice(variants), out, count=1)
        # Exclamations
        n_excl = random.randint(*cfg["excl"])
        if n_excl: out = out.rstrip(". ") + "!"*n_excl
        # Emojis
        n_emo = random.randint(*cfg["emo"])
        if n_emo: out += " " + " ".join(random.choice(cfg["emojis"]) for _ in range(n_emo))
        return out

    def __generate_delivery_feedback(self, shipment):
        row = shipment

        # Choose locale (no Faker needed)
        loc = random.choice(LOCALES)

        # Inject a few conditions
        late = random.random() < 0.10
        damaged = random.random() < (0.20 + (0.10 if row["IsFragile"] else 0))
        temp_issue = random.random() < (0.05 if row["RequiresRefrigeration"] else 0.05)

        stars = random.choices([5,4,3,2,1], weights=[45,25,15,10,5])[0]
        if late: stars -= 1
        if damaged: stars -= 1
        if temp_issue: stars -= 1
        stars = max(1, min(5, stars))

        bucket = "pos" if stars >= 4 else ("neg" if stars <= 2 else "neu")
        parts = [random.choice(PHRASES[bucket][loc])]

        if row["RequiresRefrigeration"]:
            parts.append(random.choice(PHR_FRIDGE[bucket]))
        if row["IsFragile"]:
            parts.append(random.choice(PHR_FRAGILE[bucket]))
        if row["IsHazardous"]:
            parts.append(random.choice(PHR_HAZ[bucket]))

        return self.__jitter_text(". ".join(p for p in parts if p), stars)

    def _generate_shipment(self, customer, order_id, order_lines: list):
        """Generate a realistic shipment"""
        # Generate a shipment ID
        shipment_id = str(uuid.uuid4())
        tracking_number = f"FSX{fake.bothify('???################')}".upper()
        
        # Customer information
        customer_id = customer['CustomerId']
        is_business = random.random() < 0.7  # 70% chance of business customer
        if is_business:
            customer_name = fake.company()
        else:
            customer_name = fake.name()
        
        # Select origin and destination facilities
        origin_facility = random.choice(FACILITIES)
        
        # Ensure destination is different from origin
        dest_facilities = [f for f in FACILITIES if f != origin_facility]
        destination_facility = random.choice(dest_facilities)
        
        # Generate addresses
        origin_address = self.__generate_address_near_facility(origin_facility, True)
        destination_address = self.__generate_address_near_facility(destination_facility, True)
        
        # Calculate approximate distance
        distance = self.__haversine_distance(
            origin_address["Latitude"], origin_address["Longitude"],
            destination_address["Latitude"], destination_address["Longitude"]
        )
        
        # Service level
        service_level_obj = self.__select_random_weighted(SERVICE_LEVELS)
        service_level = service_level_obj["level"]
        
        # Dates
        ship_date = datetime.now()
        delivery_days = self.__get_commits(service_level, distance)
        committed_delivery_date = ship_date + timedelta(days=delivery_days)

        # Weight and dimensions
        weight = sum(line['NetWeight'] for line in order_lines) * 1.1  # add 10% packaging weight
        
        # Assume average package density and calculate dimensions
        density_factor = random.uniform(10, 30)  # lbs per cubic foot
        volume_cubic_feet = weight / density_factor

        # Generate dimensions that multiply to approximate the volume
        # Use typical package aspect ratios
        aspect_ratio = random.choice([
            (2, 1.5, 1),    # Standard box
            (3, 2, 1),      # Flat package
            (1.5, 1.5, 1),  # Cube-ish
            (4, 2, 1)       # Long package
        ])

        # Calculate base dimension from volume
        base = (volume_cubic_feet / (aspect_ratio[0] * aspect_ratio[1] * aspect_ratio[2])) ** (1/3)

        length = round(base * aspect_ratio[0] * 12, 1)  # Convert to inches
        width = round(base * aspect_ratio[1] * 12, 1)
        height = round(base * aspect_ratio[2] * 12, 1)

        # Apply min/max constraints based on service level
        if service_level == "Freight":
            length = max(36, min(length, 96))
            width = max(24, min(width, 48))
            height = max(24, min(height, 48))
        elif service_level == "Priority":
            length = max(6, min(length, 24))
            width = max(6, min(width, 18))
            height = max(2, min(height, 12))
        else:
            length = max(4, min(length, 36))
            width = max(4, min(width, 24))
            height = max(2, min(height, 20))
        
        volume = round((length * width * height) / 1728, 2)  # convert to cubic feet
        
        # Value and special handling
        value = sum(line["ExtendedPrice"] for line in order_lines)
        
        is_hazardous = random.random() < 0.0392
        is_fragile = random.random() < 0.375
        requires_refrigeration = random.random() < 0.021
        
        # Penalty for late delivery based on value and service level
        if service_level == "Priority":
            penalty = round(value * 0.10, 2)  # 10% of value per day
        elif service_level == "Express":
            penalty = round(value * 0.05, 2)  # 5% of value per day
        elif service_level == "Freight":
            penalty = round(value * 0.03, 2)  # 3% of value per day
        else:
            penalty = round(value * 0.02, 2)  # 2% of value per day
        
        # Special instructions
        instructions = []
        if is_fragile:
            instructions.append("Handle with care")
        if requires_refrigeration:
            temp_min = random.choice([2, 35, 40])
            temp_max = temp_min + random.choice([5, 10, 15])
            temp_unit = "C" if temp_min < 10 else "F"
            instructions.append(f"Temperature controlled {temp_min}-{temp_max}{temp_unit}")
        if weight > 100:
            instructions.append("Team lift required")
        if value > 1000:
            instructions.append("High value package")
        if random.random() < 0.2 or value > 1000:
            instructions.append("Signature required")
        
        special_instructions = ", ".join(instructions) if instructions else "None"
        
        # Find closest facilities to origin and destination
        origin_facility, _ = self.__find_closest_facility(origin_address["Latitude"], origin_address["Longitude"], "Local" if random.random() < 0.7 else None)
        destination_facility, _ = self.__find_closest_facility(destination_address["Latitude"], destination_address["Longitude"], "Local" if random.random() < 0.7 else None)
        
        # Generate the shipment
        return {
            "ShipmentId": shipment_id,
            "TrackingNumber": tracking_number,
            "CustomerId": customer_id,
            "CustomerName": customer['CustomerName'],
            "OrderId": order_id,
            "OrderLineList": [line['LineNumber'] for line in order_lines],
            "ServiceLevel": service_level,
            "ShipDate": ship_date.isoformat(),
            "CommittedDeliveryDate": committed_delivery_date.isoformat(),
            
            "OriginAddress": origin_facility["Address"],
            "OriginCity": origin_facility["City"],
            "OriginState": origin_facility["State"],
            "OriginZipCode": origin_facility["ZipCode"],
            "OriginCountry": origin_facility["Country"],
            "OriginLatitude": origin_facility["Latitude"],
            "OriginLongitude": origin_facility["Longitude"],
            
            "DestinationAddress": customer['DeliveryAddress']["Address"],
            "DestinationCity": customer['DeliveryAddress']["City"],
            "DestinationState": customer['DeliveryAddress']["State"],
            "DestinationZipCode": customer['DeliveryAddress']["ZipCode"],
            "DestinationCountry": customer['DeliveryAddress']["Country"],
            "DestinationLatitude": customer['DeliveryAddress']["Latitude"],
            "DestinationLongitude": customer['DeliveryAddress']["Longitude"],
            
            "Weight": weight,
            "Length": length,
            "Width": width,
            "Height": height,
            "Volume": volume,
            "DeclaredValue": value,
            
            "IsHazardous": is_hazardous,
            "IsFragile": is_fragile,
            "RequiresRefrigeration": requires_refrigeration,
            "LateDeliveryPenaltyPerDay": penalty,
            "SpecialInstructions": special_instructions,
            
            "CurrentFacilityId": origin_facility["FacilityId"],
            "OriginFacilityId": origin_facility["FacilityId"],
            "DestinationFacilityId": destination_facility["FacilityId"],
            
            "Distance": distance
        }

    def _generate_shipment_event(self, shipment):
        """Generate a sequence of events for a shipment"""
        events = []
        event_id = str(uuid.uuid4())
        
        # Starting parameters
        current_time = datetime.fromisoformat(shipment["ShipDate"])
        current_facility = shipment["OriginFacilityId"]
        destination_facility = shipment["DestinationFacilityId"]
        event_id_counter = 1
        
        # Find the planned path
        planned_path = self.__find_optimal_path(current_facility, destination_facility)
        if not planned_path:
            # Fallback if no path found
            planned_path = [{"facility": current_facility, "next": destination_facility, 
            "route": {"RouteId": "DIRECT", "OriginFacilityId": current_facility, "DestinationFacilityId": destination_facility, "TransportMode": "Ground", "TravelTimeHours": 48.0}}]
        
        # Path as facility IDs for the snapshot
        path_snapshot = [leg["facility"] for leg in planned_path] + [destination_facility]
        
        # Create initial event
        events.append({
            "EventId": event_id,
            "SequenceNumber": event_id_counter,
            "ShipmentId": shipment["ShipmentId"],
            "TrackingNumber": shipment["TrackingNumber"],
            "EventType": "Created",
            "EventTimestamp": current_time.isoformat(),
            "FacilityId": current_facility,
            "EmployeeId": random.choice(EMPLOYEES),
            "ScanDeviceId": random.choice(SCAN_DEVICES),
            "NextWaypointFacilityId": None,
            "RouteId": None,
            "ScheduleId": None,
            "EstimatedArrivalTime": None,
            "ExceptionCode": None,
            "ExceptionSeverity": None,
            "ResolutionAction": None,
            "RelatedExceptionEventId": None,
            "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
            "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
            "SortingEquipmentId": None,
            "SortLaneId": None,
            "AdditionalData": {"method": random.choice(["Online", "API", "Counter", "Phone"])},
            "CurrentServiceLevel": shipment["ServiceLevel"],
            "CurrentOriginFacilityId": shipment["OriginFacilityId"],
            "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
            "PlannedPathSnapshot": path_snapshot
        })
        event_id_counter += 1
        
        # Advance time 30min for shipment receipt
        current_time += timedelta(minutes=random.randint(15, 45))
        events.append({
            "EventId": event_id,
            "SequenceNumber": event_id_counter,
            "ShipmentId": shipment["ShipmentId"],
            "TrackingNumber": shipment["TrackingNumber"],
            "EventType": "Received",
            "EventTimestamp": current_time.isoformat(),
            "FacilityId": current_facility,
            "EmployeeId": random.choice(EMPLOYEES),
            "ScanDeviceId": random.choice(SCAN_DEVICES),
            "NextWaypointFacilityId": None,
            "RouteId": None,
            "ScheduleId": None,
            "EstimatedArrivalTime": None,
            "ExceptionCode": None,
            "ExceptionSeverity": None,
            "ResolutionAction": None,
            "RelatedExceptionEventId": None,
            "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
            "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
            "SortingEquipmentId": None,
            "SortLaneId": None,
            "AdditionalData": {"condition": "Good"},
            "CurrentServiceLevel": shipment["ServiceLevel"],
            "CurrentOriginFacilityId": shipment["OriginFacilityId"],
            "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
            "PlannedPathSnapshot": path_snapshot
        })
        event_id_counter += 1
        
        # Process through each leg of the journey
        for i, leg in enumerate(planned_path):
            current_facility = leg["facility"]
            next_facility = leg["next"]
            route = leg["route"]
            
            # Randomize exception occurrence (5% chance for normal shipments)
            exception_occurred = random.random() < 0.05 + (0.1 if shipment["IsHazardous"] else 0)
            
            if not exception_occurred:
                # Normal processing flow
                
                # Sort decision - adds 30-90 min
                current_time += timedelta(minutes=random.randint(30, 90))
                schedule_id = f"SCH{random.randint(1000, 9999)}"
                arrival_estimate = current_time + timedelta(hours=route["TravelTimeHours"])
                
                events.append({
                    "EventId": event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Processed",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SORTER" in d]),
                    "NextWaypointFacilityId": next_facility,
                    "RouteId": route["RouteId"],
                    "ScheduleId": schedule_id,
                    "EstimatedArrivalTime": arrival_estimate.isoformat(),
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": random.choice(["SORT01", "SORT02", "SORT03"]),
                    "SortLaneId": f"LANE{random.randint(1, 20):02d}",
                    "AdditionalData": {"sortDecision": "Optimal route" if i == 0 else "Continuing on route"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Departure - adds 1-3 hours
                current_time += timedelta(hours=random.randint(1, 3))
                events.append({
                    "EventId": event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Departed",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": next_facility,
                    "RouteId": route["RouteId"],
                    "ScheduleId": schedule_id,
                    "EstimatedArrivalTime": arrival_estimate.isoformat(),
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {
                        "loadId": f"LD{random.randint(1000, 9999)}"
                        #"transportType": "Flight" if route["TransportMode"] == "Air" else "Truck"
                    },
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Possible in-transit GPS updates for longer routes
                if route["TravelTimeHours"] > 4:
                    # Number of updates based on journey length
                    num_updates = min(int(route["TravelTimeHours"] / 4), 5)
                    for _ in range(num_updates):
                        current_time += timedelta(hours=route["TravelTimeHours"] / (num_updates + 1))
                        
                        # Calculate a point along the route
                        origin_lat = next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), 0)
                        origin_lng = next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), 0)
                        dest_lat = next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == next_facility), 0)
                        dest_lng = next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == next_facility), 0)
                        
                        # Simple linear interpolation
                        progress = (_ + 1) / (num_updates + 1)
                        current_lat = origin_lat + (dest_lat - origin_lat) * progress
                        current_lng = origin_lng + (dest_lng - origin_lng) * progress
                        
                        # Add some random noise
                        current_lat += random.uniform(-0.05, 0.05)
                        current_lng += random.uniform(-0.05, 0.05)
                        
                        events.append({
                            "EventId": event_id,
                            "SequenceNumber": event_id_counter,
                            "ShipmentId": shipment["ShipmentId"],
                            "TrackingNumber": shipment["TrackingNumber"],
                            "EventType": "InTransit",
                            "EventTimestamp": current_time.isoformat(),
                            "FacilityId": None,
                            "EmployeeId": "SYSTEM",
                            "ScanDeviceId": "GPS001",
                            "NextWaypointFacilityId": next_facility,
                            "RouteId": route["RouteId"],
                            "ScheduleId": schedule_id,
                            "EstimatedArrivalTime": arrival_estimate.isoformat(),
                            "ExceptionCode": None,
                            "ExceptionSeverity": None,
                            "ResolutionAction": None,
                            "RelatedExceptionEventId": None,
                            "LocationLatitude": current_lat,
                            "LocationLongitude": current_lng,
                            "SortingEquipmentId": None,
                            "SortLaneId": None,
                            "AdditionalData": {
                                "vehicleId": f"{'FLIGHT' if route['TransportMode']=='Air' else 'TRUCK'}{random.randint(100, 999)}"
                            },
                            "CurrentServiceLevel": shipment["ServiceLevel"],
                            "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                            "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                            "PlannedPathSnapshot": path_snapshot
                        })
                        event_id_counter += 1
                
                # Arrival at next facility - add the travel time with some variance
                travel_variance = random.uniform(0.85, 1.15)  # +/- 15%
                current_time += timedelta(hours=route["TravelTimeHours"] * travel_variance) - timedelta(hours=route["TravelTimeHours"] / (num_updates + 1) * num_updates if route["TravelTimeHours"] > 4 else 0)
                
                # Update the current facility
                current_facility = next_facility
                
                # Receipt at next facility
                events.append({
                    "EventId": event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Received",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"condition": "Good"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
            
            else:
                # Handle exception case
                current_time += timedelta(minutes=random.randint(30, 90))
                exception = random.choice(EXCEPTION_TYPES)
                exception_event_id = event_id
                
                events.append({
                    "EventId": exception_event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Exception",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": exception["code"],
                    "ExceptionSeverity": exception["severity"],
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"reason": exception["description"]},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Add time for resolution
                current_time += timedelta(hours=random.randint(1, 8))
                resolution_action = random.choice(RESOLUTION_ACTIONS)
                
                events.append({
                    "EventId": event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "ExceptionResolved",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": resolution_action,
                    "RelatedExceptionEventId": exception_event_id,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"resolution": f"{resolution_action} completed"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # If the exception impacts routing, we may need to adjust the path
                if resolution_action == "Reroute":
                    # Maybe we need to insert a different destination facility
                    # Simplified for now - just proceed with the original path
                    events.append({
                        "EventId": event_id,
                        "SequenceNumber": event_id_counter,
                        "ShipmentId": shipment["ShipmentId"],
                        "TrackingNumber": shipment["TrackingNumber"],
                        "EventType": "Rerouted",
                        "EventTimestamp": current_time.isoformat(),
                        "FacilityId": current_facility,
                        "EmployeeId": random.choice(EMPLOYEES),
                        "ScanDeviceId": "SYSTEM",
                        "NextWaypointFacilityId": next_facility,
                        "RouteId": route["RouteId"],
                        "ScheduleId": f"SCH{random.randint(1000, 9999)}",
                        "EstimatedArrivalTime": (current_time + timedelta(hours=route["TravelTimeHours"])).isoformat(),
                        "ExceptionCode": None,
                        "ExceptionSeverity": None,
                        "ResolutionAction": None,
                        "RelatedExceptionEventId": None,
                        "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                        "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                        "SortingEquipmentId": None,
                        "SortLaneId": None,
                        "AdditionalData": {"reroute": "Path resumed after exception"},
                        "CurrentServiceLevel": shipment["ServiceLevel"],
                        "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                        "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                        "PlannedPathSnapshot": path_snapshot
                    })
                    event_id_counter += 1
                    
                # Continue with departure and receipt as in normal flow
                current_time += timedelta(hours=random.randint(1, 3))
                schedule_id = f"SCH{random.randint(1000, 9999)}"
                arrival_estimate = current_time + timedelta(hours=route["TravelTimeHours"])
                
                events.append({
                    "EventId": event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Departed",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": next_facility,
                    "RouteId": route["RouteId"],
                    "ScheduleId": schedule_id,
                    "EstimatedArrivalTime": arrival_estimate.isoformat(),
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {
                        "loadId": f"LD{random.randint(1000, 9999)}",
                        "transportType": "Flight" if route["TransportMode"] == "Air" else "Truck"
                    },
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Update the current facility after travel
                travel_variance = random.uniform(0.85, 1.15)  # +/- 15%
                current_time += timedelta(hours=route["TravelTimeHours"] * travel_variance)
                current_facility = next_facility
                
                # Receipt at next facility
                events.append({
                    "EventId": event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Received",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"condition": "Good"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
        
        # Add final delivery events if we've gone through all legs and reached the final facility
        if current_facility == destination_facility:
            # Out for delivery
            current_time += timedelta(hours=random.randint(1, 4))
            events.append({
                "EventId": event_id,
                "SequenceNumber": event_id_counter,
                "ShipmentId": shipment["ShipmentId"],
                "TrackingNumber": shipment["TrackingNumber"],
                "EventType": "OutForDelivery",
                "EventTimestamp": current_time.isoformat(),
                "FacilityId": current_facility,
                "EmployeeId": random.choice(EMPLOYEES),
                "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "MOBILE" in d]),
                "NextWaypointFacilityId": None,
                "RouteId": None,
                "ScheduleId": None,
                "EstimatedArrivalTime": None,
                "ExceptionCode": None,
                "ExceptionSeverity": None,
                "ResolutionAction": None,
                "RelatedExceptionEventId": None,
                "LocationLatitude": next((f["Latitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                "LocationLongitude": next((f["Longitude"] for f in FACILITIES if f["FacilityId"] == current_facility), None),
                "SortingEquipmentId": None,
                "SortLaneId": None,
                "AdditionalData": {"vehicleId": f"VAN{random.randint(100, 999)}", "stopSequence": random.randint(1, 30)},
                "CurrentServiceLevel": shipment["ServiceLevel"],
                "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                "PlannedPathSnapshot": path_snapshot + ["CUSTOMER"]
            })
            event_id_counter += 1
            
            # Possible delivery exception (10% chance)
            delivery_exception = random.random() < 0.1
            if delivery_exception:
                current_time += timedelta(hours=random.randint(2, 6))
                exception_event_id = event_id
                
                events.append({
                    "EventId": exception_event_id,
                    "SequenceNumber": event_id_counter,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "DeliveryAttempted",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(EMPLOYEES),
                    "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "MOBILE" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": "NOONE",
                    "ExceptionSeverity": "Minor",
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": shipment["DestinationLatitude"],
                    "LocationLongitude": shipment["DestinationLongitude"],
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"note": "No one at delivery address"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot + ["CUSTOMER"]
                })
                event_id_counter += 1
                
                # Next delivery attempt
                current_time += timedelta(hours=random.randint(1, 4))
            else:
                # Normal delivery flow
                current_time += timedelta(hours=random.randint(1, 6))
            
            # Delivered
            events.append({
                "EventId": event_id,
                "SequenceNumber": event_id_counter,
                "ShipmentId": shipment["ShipmentId"],
                "TrackingNumber": shipment["TrackingNumber"],
                "EventType": "Delivered",
                "EventTimestamp": current_time.isoformat(),
                "FacilityId": current_facility,
                "EmployeeId": random.choice(EMPLOYEES),
                "ScanDeviceId": random.choice([d for d in SCAN_DEVICES if "MOBILE" in d]),
                "NextWaypointFacilityId": None,
                "RouteId": None,
                "ScheduleId": None,
                "EstimatedArrivalTime": None,
                "ExceptionCode": None,
                "ExceptionSeverity": None,
                "ResolutionAction": None,
                "RelatedExceptionEventId": None,
                "LocationLatitude": shipment["DestinationLatitude"],
                "LocationLongitude": shipment["DestinationLongitude"],
                "SortingEquipmentId": None,
                "SortLaneId": None,
                "AdditionalData": {
                    "signedBy": fake.name() if random.random() < 0.752 else "", 
                    "review": self.__generate_delivery_feedback(shipment) if random.random() < 0.6396 else ""
                    },
                "CurrentServiceLevel": shipment["ServiceLevel"],
                "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                "PlannedPathSnapshot": []
            })
        
        return events