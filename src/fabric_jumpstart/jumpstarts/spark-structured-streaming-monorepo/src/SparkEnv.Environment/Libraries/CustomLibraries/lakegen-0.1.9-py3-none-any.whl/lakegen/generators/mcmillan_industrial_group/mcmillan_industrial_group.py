import json
import time
import random
import zlib
import pandas as pd
import socket
from datetime import datetime
from faker import Faker

# from azure.eventhub import EventHubProducerClient, EventData
# from azure.eventhub.exceptions import EventHubError
# file target
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import timezone
import posixpath
from typing import Optional
import fsspec

from lakegen.generators.base import BaseGenerator

from .entity.shipment import Shipment
from .entity.customer import Customer
from .entity.order import Order
from .entity.item import Item

from .entity import shipment_lookups as lookups

# Initialize Faker
fake = Faker()


class McMillanDataGen(BaseGenerator):
    TABLES = [
        "shipment",
        "shipment_scan_event",
        "order",
        "customer",
        "item",
        "route",
        "servicelevel",
        "facility",
        "exceptiontype",
    ]

    def __init__(
        self,
        target_folder_uri: str = None,
        output_type_map: Optional[dict] = None,
        concurrenct_threads: int = 1,
        sec_delay_between_batches: int = None,
        max_events_per_second: int = None,
    ):
        super().__init__(target_folder_uri)
        self.output_type_map = output_type_map
        self.concurrenct_threads = concurrenct_threads
        self.sec_delay_between_batches = sec_delay_between_batches
        self.max_events_per_second = max_events_per_second
        for table in self.TABLES:
            self.fs.mkdirs(posixpath.join(self.target_folder_uri, table), exist_ok=True)

        # Thread control
        self._telemetry_threads = []
        self._telemetry_stop = threading.Event()
        self._telemetry_start_time = None
        self._total_shipment_count = 0
        self._total_scan_event_count = 0
        self._total_order_count = 0
        self._system_id = zlib.crc32(socket.gethostname().encode()) & 0xFFFFFFFF
        self._item_catalog = Item().generate_items(count=500)
        self._customer_id_set = set()  # Use set for O(1) lookups instead of O(n)

        # Thread-safe locks for shared resources
        self._item_catalog_lock = threading.Lock()
        self._customer_set_lock = threading.Lock()

    def __now_utc_iso(self):
        return datetime.now(timezone.utc).isoformat()

    def __add_standard_columns(self, data: list):
        """Add standard metadata columns to each record in the data list."""
        timestamp = self.__now_utc_iso()
        for record in data:
            record["OrganizationId"] = self._system_id
            record["GeneratedAt"] = timestamp
        return data

    def _write_output_data(
        self,
        folder_uri: str,
        table_name: str,
        format: str,
        data: list,
        skip_if_non_empty_root: bool = False,
    ):
        ts = int(time.time() * 1000)
        table_folder_uri = posixpath.join(folder_uri, table_name)
        # remove files in folder if mode is 'Overwrite'
        if skip_if_non_empty_root:
            try:
                existing_file_count = len(self.fs.ls(table_folder_uri))
            except FileNotFoundError:
                existing_file_count = 0
                pass
            if existing_file_count > 0:
                return None  # skip write, i.e. static reference data already exists

        if format.lower() == "json":
            return self._write_json_file(
                posixpath.join(table_folder_uri, f"{table_name}_{ts}.json"),
                data,
                record_type=table_name,
            )
        elif format.lower() == "parquet":
            return self._write_parquet_file(
                posixpath.join(table_folder_uri, f"{table_name}_{ts}.parquet"),
                data,
            )
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _write_json_file(self, file_uri: Path, data: list, record_type: str):
        data = self.__add_standard_columns(data)
        """Write a list of dicts to one JSON file with a header."""
        payload = {
            "_meta": {
                "schemaVersion": "1.0",
                "producer": "lakegen.mcmillan",
                "recordType": record_type,
                "enqueuedTime": self.__now_utc_iso(),
            },
            "data": data,
        }
        with fsspec.open(file_uri, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return file_uri

    def _write_parquet_file(self, file_path: str, data: list):
        """Write a list of dicts to one parquet file."""
        import pyarrow as pa
        import pyarrow.parquet as pq

        data = self.__add_standard_columns(data)

        table = pa.Table.from_pandas(pd.DataFrame(data))
        
        # Use fsspec to write the parquet file to support abfss:// and other protocols
        with fsspec.open(file_path, 'wb') as f:
            pq.write_table(table, f)

    def _write_static_reference_data(self):
        """Write static reference data files."""
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="item",
            format=self.output_type_map.get("item", "json"),
            data=self._item_catalog,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="route",
            format=self.output_type_map.get("route", "json"),
            data=lookups.ROUTES,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="servicelevel",
            format=self.output_type_map.get("servicelevel", "json"),
            data=lookups.SERVICE_LEVELS,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="facility",
            format=self.output_type_map.get("facility", "json"),
            data=lookups.FACILITIES,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="exceptiontype",
            format=self.output_type_map.get("exceptiontype", "json"),
            data=lookups.EXCEPTION_TYPES,
            skip_if_non_empty_root=True,
        )

    def _start_generator_thread(self, verbose=True):
        """Worker function to send telemetry until stop event is set."""
        total_scan_event_count = 0
        start_time = time.time()

        try:
            if verbose:
                print(
                    f"[{threading.current_thread().name}] Starting generator thread..."
                )
                print(
                    f"[{threading.current_thread().name}] Stop event is set: {self._telemetry_stop.is_set()}"
                )

            while not self._telemetry_stop.is_set():
                (
                    shipment_buffer,
                    scan_event_buffer,
                    order_buffer,
                    customer_buffer,
                    item_buffer,
                ) = [], [], [], [], []

                shipment_instance = Shipment()

                max_customers = min(
                    max(int(self._total_shipment_count**0.6), 10), 99_999_999
                )
                # TODO: move seed to input parameter to cascade down to all faker instances

                customer_instance = Customer()
                order_instance = Order()
                item_instance = Item()

                if random.random() < 0.02:
                    items = item_instance.generate_items(count=10)
                    item_buffer.extend(items)
                    with self._item_catalog_lock:
                        self._item_catalog.extend(items)

                # create a random batch
                for _ in range(1, random.randint(10, 50)):
                    customer_seed = random.randint(int(1), int(max_customers))
                    customer = customer_instance._generate_customer(seed=customer_seed)

                    # don't recreate the same customer
                    with self._customer_set_lock:
                        if customer["CustomerId"] not in self._customer_id_set:
                            self._customer_id_set.add(customer["CustomerId"])
                            customer_buffer.append(customer)

                    # create order for customer
                    with self._item_catalog_lock:
                        order = order_instance._generate_order(
                            customer, self._item_catalog
                        )
                    order_buffer.append(order)

                    # for each order line, create shipment and events

                    def _process_order_lines(customer, order_id, order_lines: list):
                        shipment = shipment_instance._generate_shipment(
                            customer, order_id, order_lines
                        )
                        shipment_events = shipment_instance._generate_shipment_event(
                            shipment
                        )
                        shipment_buffer.append(shipment)
                        scan_event_buffer.extend(shipment_events)

                    order_line_buffer = []
                    for index, order_line in enumerate(order["OrderLines"]):
                        # chance of order lines being shipped together
                        if (
                            random.random() > 0.4
                            or index == len(order["OrderLines"]) - 1
                        ):
                            order_line_buffer.append(order_line)
                            _process_order_lines(
                                customer, order["OrderId"], order_line_buffer
                            )
                            order_line_buffer = []
                        else:
                            order_line_buffer.append(order_line)

                # Auto-tuning throttling: control event generation rate after first batch
                if self.max_events_per_second is not None and total_scan_event_count > 0:
                    # Calculate per-thread target EPS
                    max_thread_eps = self.max_events_per_second / max(1, self.concurrenct_threads)
                    
                    # Calculate how many events we just generated
                    batch_scan_event_count = len(scan_event_buffer)
                    
                    # Calculate how long this batch SHOULD take at target rate
                    target_time_for_batch = batch_scan_event_count / max_thread_eps
                    
                    # Always sleep for the target time to maintain steady rate
                    # This prevents spiky behavior and maintains consistent throughput
                    if verbose:
                        elapsed_time = time.time() - start_time
                        current_eps = total_scan_event_count / elapsed_time if elapsed_time > 0 else 0
                        print(
                            f"[{threading.current_thread().name}] "
                            f"Throttling: current_eps={current_eps:.2f}, target={max_thread_eps:.2f}, "
                            f"sleeping {target_time_for_batch:.3f}s for {batch_scan_event_count} events"
                        )
                    time.sleep(target_time_for_batch)

                if len(item_buffer) > 0:
                    self._write_output_data(
                        folder_uri=self.target_folder_uri,
                        table_name="item",
                        format=self.output_type_map.get("item", "json"),
                        data=item_buffer,
                    )
                if len(customer_buffer) > 0:
                    self._write_output_data(
                        folder_uri=self.target_folder_uri,
                        table_name="customer",
                        format=self.output_type_map.get("customer", "json"),
                        data=customer_buffer,
                    )
                self._write_output_data(
                    folder_uri=self.target_folder_uri,
                    table_name="order",
                    format=self.output_type_map.get("order", "json"),
                    data=order_buffer,
                )
                self._write_output_data(
                    folder_uri=self.target_folder_uri,
                    table_name="shipment",
                    format=self.output_type_map.get("shipment", "json"),
                    data=shipment_buffer,
                )
                self._write_output_data(
                    folder_uri=self.target_folder_uri,
                    table_name="shipment_scan_event",
                    format=self.output_type_map.get("shipment_scan_event", "json"),
                    data=scan_event_buffer,
                )

                batch_order_count = len(order_buffer)
                self._total_order_count += batch_order_count
                batch_shipment_count = len(shipment_buffer)
                self._total_shipment_count += (
                    batch_shipment_count
                )
                batch_scan_event_count = len(scan_event_buffer)
                total_scan_event_count += batch_scan_event_count
                self._total_scan_event_count += batch_scan_event_count
                elapsed_time = time.time() - start_time
                eps = total_scan_event_count / elapsed_time if elapsed_time > 0 else 0

                if verbose:
                    print(
                        f"[{threading.current_thread().name}] "
                        f"Batch complete - Shipments: {batch_shipment_count}, Orders: {batch_order_count}, "
                        f"Customers: {len(customer_buffer)}, Items: {len(item_buffer)}, Scan Events: {batch_scan_event_count} | "
                        f"Total Scan Events: {total_scan_event_count}, EPS: {eps:.2f}"
                    )

                if self.sec_delay_between_batches:
                    time.sleep(self.sec_delay_between_batches)

        except Exception as e:
            print(f"[{threading.current_thread().name}] ERROR: {e}")
            import traceback

            traceback.print_exc()
        finally:
            elapsed_time = time.time() - start_time
            eps = total_scan_event_count / elapsed_time if elapsed_time > 0 else 0
            return total_scan_event_count, eps

    def start(self, verbose=True, background=True):
        """
        Start telemetry producer.

        Args:
            concurrency: Number of concurrent worker threads
            verbose: Print progress messages
            background: If True, run in background thread. If False, block until interrupted.

        Returns:
            (total_events, total_eps) if background=False, otherwise None
        """
        if self._telemetry_threads and any(
            t.is_alive() for t in self._telemetry_threads
        ):
            print("Generator already running.")
            return

        # write static reference data
        self._write_static_reference_data()

        # Clear stop event for new run
        self._telemetry_stop.clear()
        self._total_scan_event_count = 0  # Reset counter
        self._telemetry_start_time = time.time()  # Record start time

        def _runner():
            try:
                results = []
                start_time = time.time()

                with ThreadPoolExecutor(max_workers=self.concurrenct_threads) as executor:
                    futures = [
                        executor.submit(self._start_generator_thread, verbose)
                        for _ in range(self.concurrenct_threads)
                    ]
                    try:
                        for future in as_completed(futures):
                            results.append(future.result())
                    except KeyboardInterrupt:
                        print(
                            "Background thread received interrupt. Stopping all workers..."
                        )
                        self._telemetry_stop.set()
                        for future in futures:
                            try:
                                results.append(future.result())
                            except Exception as e:
                                print(f"Thread terminated with error: {e}")

                total_events = sum(r[0] for r in results) if results else 0
                total_elapsed = time.time() - start_time
                total_eps = total_events / total_elapsed if total_elapsed > 0 else 0
                print(
                    f"[Runner] exited: total_events={total_events}, eps={total_eps:.2f}"
                )
            except Exception as e:
                print(f"[Runner] error: {e}")

        if background:
            # Run in background thread
            thread = threading.Thread(target=_runner, name="Runner", daemon=False)
            thread.start()
            self._telemetry_threads = [thread]
            print(
                f"Generator started in background with {self.concurrenct_threads} concurrent worker(s)."
            )
            print("Call gen.stop() to stop generation.")
        else:
            # Run in foreground (blocking)
            print(f"Generator starting with {self.concurrenct_threads} concurrent worker(s).")
            print("Interrupt the process to stop generation.")

            _runner()

    def stop(self, timeout=10):
        """Signal the background producer to stop and join all threads."""
        if not self._telemetry_threads:
            print("Generator not running.")
            return

        print("Stopping generator...")
        self._telemetry_stop.set()

        for thread in self._telemetry_threads:
            thread.join(timeout=timeout)
            if thread.is_alive():
                print(
                    f"Thread {thread.name} is taking longer to stop; it will exit after the current batch."
                )

        if not any(t.is_alive() for t in self._telemetry_threads):
            print("Generator stopped.")

        self._telemetry_threads = []

    def status(self):
        """Check if telemetry is currently running and print metrics."""
        is_running = bool(self._telemetry_threads) and any(
            t.is_alive() for t in self._telemetry_threads
        )

        if is_running:
            elapsed_time = (
                time.time() - self._telemetry_start_time
                if self._telemetry_start_time
                else 0
            )
            eps = self._total_scan_event_count / elapsed_time if elapsed_time > 0 else 0
            print(
                f"Generator running: total_events={self._total_scan_event_count}, eps={eps:.2f}, elapsed={elapsed_time:.1f}s"
            )
        else:
            print("Generator not running.")

        return is_running
