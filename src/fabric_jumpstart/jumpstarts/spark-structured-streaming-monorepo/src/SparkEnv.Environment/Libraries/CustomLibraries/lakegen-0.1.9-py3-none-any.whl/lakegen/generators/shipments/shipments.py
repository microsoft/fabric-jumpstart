import json
import time
import uuid
import random
import re
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from faker import Faker

#from azure.eventhub import EventHubProducerClient, EventData
#from azure.eventhub.exceptions import EventHubError
# file target
import time
import json
from pathlib import Path
import random
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import posixpath


# Initialize Faker
fake = Faker()

# Delivery Feedback
import re, random

# Set random seed for reproducibility
random.seed(42)
np.random.seed(42)

class ShipmentsGen:
    FACILITIES = [
        {"FacilityId": "HUB001", "FacilityName": "Atlanta Hub", "FacilityType": "Hub", "City": "Atlanta", "State": "GA", "ZipCode": "30320", "Latitude": 33.6407, "Longitude": -84.4277},
        {"FacilityId": "HUB002", "FacilityName": "Chicago Hub", "FacilityType": "Hub", "City": "Chicago", "State": "IL", "ZipCode": "60666", "Latitude": 41.9742, "Longitude": -87.9073},
        {"FacilityId": "HUB003", "FacilityName": "Denver Hub", "FacilityType": "Hub", "City": "Denver", "State": "CO", "ZipCode": "80249", "Latitude": 39.8561, "Longitude": -104.6737},
        {"FacilityId": "DC001", "FacilityName": "Dallas Distribution Center", "FacilityType": "Distribution", "City": "Dallas", "State": "TX", "ZipCode": "75261", "Latitude": 32.8998, "Longitude": -97.0403},
        {"FacilityId": "DC002", "FacilityName": "Phoenix Distribution Center", "FacilityType": "Distribution", "City": "Phoenix", "State": "AZ", "ZipCode": "85034", "Latitude": 33.4352, "Longitude": -112.0101},
        {"FacilityId": "DC003", "FacilityName": "Seattle Distribution Center", "FacilityType": "Distribution", "City": "Seattle", "State": "WA", "ZipCode": "98158", "Latitude": 47.4502, "Longitude": -122.3088},
        {"FacilityId": "DC004", "FacilityName": "Columbus Distribution Center", "FacilityType": "Distribution", "City": "Columbus", "State": "OH", "ZipCode": "43219", "Latitude": 39.9612, "Longitude": -82.9988},
        {"FacilityId": "DC005", "FacilityName": "Louisville Distribution Center", "FacilityType": "Distribution", "City": "Louisville", "State": "KY", "ZipCode": "40209", "Latitude": 38.1781, "Longitude": -85.7369},
        {"FacilityId": "LC001", "FacilityName": "New York City Local", "FacilityType": "Local", "City": "New York", "State": "NY", "ZipCode": "10001", "Latitude": 40.7128, "Longitude": -74.0060},
        {"FacilityId": "LC002", "FacilityName": "Los Angeles Local", "FacilityType": "Local", "City": "Los Angeles", "State": "CA", "ZipCode": "90001", "Latitude": 34.0522, "Longitude": -118.2437},
        {"FacilityId": "LC003", "FacilityName": "Miami Local", "FacilityType": "Local", "City": "Miami", "State": "FL", "ZipCode": "33126", "Latitude": 25.7617, "Longitude": -80.1918},
        {"FacilityId": "LC004", "FacilityName": "Boston Local", "FacilityType": "Local", "City": "Boston", "State": "MA", "ZipCode": "02128", "Latitude": 42.3601, "Longitude": -71.0589},
        {"FacilityId": "LC005", "FacilityName": "San Francisco Local", "FacilityType": "Local", "City": "San Francisco", "State": "CA", "ZipCode": "94128", "Latitude": 37.7749, "Longitude": -122.4194}
    ]

    ROUTES = [
        # Hub to Hub routes (Air and Ground)
        {"RouteId": "RT001", "OriginFacilityId": "HUB001", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 2.0},
        {"RouteId": "RT002", "OriginFacilityId": "HUB002", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 1.9},
        {"RouteId": "RT003", "OriginFacilityId": "HUB001", "DestinationFacilityId": "HUB002", "TransportMode": "Ground", "TravelTimeHours": 12.5},
        {"RouteId": "RT004", "OriginFacilityId": "HUB002", "DestinationFacilityId": "HUB001", "TransportMode": "Ground", "TravelTimeHours": 12.3},
        {"RouteId": "RT005", "OriginFacilityId": "HUB001", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 3.2},
        {"RouteId": "RT006", "OriginFacilityId": "HUB003", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 3.1},
        {"RouteId": "RT007", "OriginFacilityId": "HUB001", "DestinationFacilityId": "HUB003", "TransportMode": "Ground", "TravelTimeHours": 24.5},
        {"RouteId": "RT008", "OriginFacilityId": "HUB003", "DestinationFacilityId": "HUB001", "TransportMode": "Ground", "TravelTimeHours": 24.3},
        {"RouteId": "RT009", "OriginFacilityId": "HUB002", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.4},
        {"RouteId": "RT010", "OriginFacilityId": "HUB003", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 2.3},
        {"RouteId": "RT011", "OriginFacilityId": "HUB002", "DestinationFacilityId": "HUB003", "TransportMode": "Ground", "TravelTimeHours": 16.8},
        {"RouteId": "RT012", "OriginFacilityId": "HUB003", "DestinationFacilityId": "HUB002", "TransportMode": "Ground", "TravelTimeHours": 16.7},

        # Hub to Distribution Center routes
        {"RouteId": "RT013", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 2.2},
        {"RouteId": "RT014", "OriginFacilityId": "DC001", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 2.1},
        {"RouteId": "RT015", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC001", "TransportMode": "Ground", "TravelTimeHours": 14.0},
        {"RouteId": "RT016", "OriginFacilityId": "DC001", "DestinationFacilityId": "HUB001", "TransportMode": "Ground", "TravelTimeHours": 14.2},
        {"RouteId": "RT017", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 3.4},
        {"RouteId": "RT018", "OriginFacilityId": "DC002", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 3.3},
        {"RouteId": "RT019", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 5.5},
        {"RouteId": "RT020", "OriginFacilityId": "DC003", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 5.4},
        {"RouteId": "RT021", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 1.8},
        {"RouteId": "RT022", "OriginFacilityId": "DC004", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 1.7},
        {"RouteId": "RT023", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC004", "TransportMode": "Ground", "TravelTimeHours": 9.2},
        {"RouteId": "RT024", "OriginFacilityId": "DC004", "DestinationFacilityId": "HUB001", "TransportMode": "Ground", "TravelTimeHours": 9.4},
        {"RouteId": "RT025", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 1.3},
        {"RouteId": "RT026", "OriginFacilityId": "DC005", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 1.2},
        {"RouteId": "RT027", "OriginFacilityId": "HUB001", "DestinationFacilityId": "DC005", "TransportMode": "Ground", "TravelTimeHours": 7.0},
        {"RouteId": "RT028", "OriginFacilityId": "DC005", "DestinationFacilityId": "HUB001", "TransportMode": "Ground", "TravelTimeHours": 7.2},
        {"RouteId": "RT029", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 2.2},
        {"RouteId": "RT030", "OriginFacilityId": "DC001", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 2.1},
        {"RouteId": "RT031", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 3.5},
        {"RouteId": "RT032", "OriginFacilityId": "DC002", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 3.4},
        {"RouteId": "RT033", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 4.0},
        {"RouteId": "RT034", "OriginFacilityId": "DC003", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 3.9},
        {"RouteId": "RT035", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 1.2},
        {"RouteId": "RT036", "OriginFacilityId": "DC004", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 1.1},
        {"RouteId": "RT037", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC004", "TransportMode": "Ground", "TravelTimeHours": 6.5},
        {"RouteId": "RT038", "OriginFacilityId": "DC004", "DestinationFacilityId": "HUB002", "TransportMode": "Ground", "TravelTimeHours": 6.7},
        {"RouteId": "RT039", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 1.4},
        {"RouteId": "RT040", "OriginFacilityId": "DC005", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 1.3},
        {"RouteId": "RT041", "OriginFacilityId": "HUB002", "DestinationFacilityId": "DC005", "TransportMode": "Ground", "TravelTimeHours": 6.8},
        {"RouteId": "RT042", "OriginFacilityId": "DC005", "DestinationFacilityId": "HUB002", "TransportMode": "Ground", "TravelTimeHours": 7.0},
        {"RouteId": "RT043", "OriginFacilityId": "HUB003", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 2.1},
        {"RouteId": "RT044", "OriginFacilityId": "DC001", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.0},
        {"RouteId": "RT045", "OriginFacilityId": "HUB003", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 1.7},
        {"RouteId": "RT046", "OriginFacilityId": "DC002", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 1.6},
        {"RouteId": "RT047", "OriginFacilityId": "HUB003", "DestinationFacilityId": "DC002", "TransportMode": "Ground", "TravelTimeHours": 16.0},
        {"RouteId": "RT048", "OriginFacilityId": "DC002", "DestinationFacilityId": "HUB003", "TransportMode": "Ground", "TravelTimeHours": 15.8},
        {"RouteId": "RT049", "OriginFacilityId": "HUB003", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 2.3},
        {"RouteId": "RT050", "OriginFacilityId": "DC003", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.2},
        {"RouteId": "RT051", "OriginFacilityId": "HUB003", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 2.8},
        {"RouteId": "RT052", "OriginFacilityId": "DC004", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.7},
        {"RouteId": "RT053", "OriginFacilityId": "HUB003", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 2.5},
        {"RouteId": "RT054", "OriginFacilityId": "DC005", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.4},

        # Hub to Local routes
        {"RouteId": "RT055", "OriginFacilityId": "HUB001", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 2.3},
        {"RouteId": "RT056", "OriginFacilityId": "LC001", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 2.2},
        {"RouteId": "RT057", "OriginFacilityId": "HUB001", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 4.8},
        {"RouteId": "RT058", "OriginFacilityId": "LC002", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 4.7},
        {"RouteId": "RT059", "OriginFacilityId": "HUB001", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 1.8},
        {"RouteId": "RT060", "OriginFacilityId": "LC003", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 1.7},
        {"RouteId": "RT061", "OriginFacilityId": "HUB001", "DestinationFacilityId": "LC003", "TransportMode": "Ground", "TravelTimeHours": 12.5},
        {"RouteId": "RT062", "OriginFacilityId": "LC003", "DestinationFacilityId": "HUB001", "TransportMode": "Ground", "TravelTimeHours": 12.7},
        {"RouteId": "RT063", "OriginFacilityId": "HUB001", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 2.4},
        {"RouteId": "RT064", "OriginFacilityId": "LC004", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 2.3},
        {"RouteId": "RT065", "OriginFacilityId": "HUB001", "DestinationFacilityId": "LC005", "TransportMode": "Air", "TravelTimeHours": 5.2},
        {"RouteId": "RT066", "OriginFacilityId": "LC005", "DestinationFacilityId": "HUB001", "TransportMode": "Air", "TravelTimeHours": 5.1},
        {"RouteId": "RT067", "OriginFacilityId": "HUB002", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 2.0},
        {"RouteId": "RT068", "OriginFacilityId": "LC001", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 1.9},
        {"RouteId": "RT069", "OriginFacilityId": "HUB002", "DestinationFacilityId": "LC001", "TransportMode": "Ground", "TravelTimeHours": 16.0},
        {"RouteId": "RT070", "OriginFacilityId": "LC001", "DestinationFacilityId": "HUB002", "TransportMode": "Ground", "TravelTimeHours": 16.2},
        {"RouteId": "RT071", "OriginFacilityId": "HUB002", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 4.1},
        {"RouteId": "RT072", "OriginFacilityId": "LC002", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 4.0},
        {"RouteId": "RT073", "OriginFacilityId": "HUB002", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 3.0},
        {"RouteId": "RT074", "OriginFacilityId": "LC003", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 2.9},
        {"RouteId": "RT075", "OriginFacilityId": "HUB002", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 1.9},
        {"RouteId": "RT076", "OriginFacilityId": "LC004", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 1.8},
        {"RouteId": "RT077", "OriginFacilityId": "HUB002", "DestinationFacilityId": "LC005", "TransportMode": "Air", "TravelTimeHours": 4.3},
        {"RouteId": "RT078", "OriginFacilityId": "LC005", "DestinationFacilityId": "HUB002", "TransportMode": "Air", "TravelTimeHours": 4.2},
        {"RouteId": "RT079", "OriginFacilityId": "HUB003", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 4.2},
        {"RouteId": "RT080", "OriginFacilityId": "LC001", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 4.1},
        {"RouteId": "RT081", "OriginFacilityId": "HUB003", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 2.3},
        {"RouteId": "RT082", "OriginFacilityId": "LC002", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.2},
        {"RouteId": "RT083", "OriginFacilityId": "HUB003", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 4.5},
        {"RouteId": "RT084", "OriginFacilityId": "LC003", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 4.4},
        {"RouteId": "RT085", "OriginFacilityId": "HUB003", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 4.3},
        {"RouteId": "RT086", "OriginFacilityId": "LC004", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 4.2},
        {"RouteId": "RT087", "OriginFacilityId": "HUB003", "DestinationFacilityId": "LC005", "TransportMode": "Air", "TravelTimeHours": 2.1},
        {"RouteId": "RT088", "OriginFacilityId": "LC005", "DestinationFacilityId": "HUB003", "TransportMode": "Air", "TravelTimeHours": 2.0},
        {"RouteId": "RT089", "OriginFacilityId": "HUB003", "DestinationFacilityId": "LC005", "TransportMode": "Ground", "TravelTimeHours": 18.5},
        {"RouteId": "RT090", "OriginFacilityId": "LC005", "DestinationFacilityId": "HUB003", "TransportMode": "Ground", "TravelTimeHours": 18.7},

        # Distribution Center to Distribution Center routes
        {"RouteId": "RT091", "OriginFacilityId": "DC001", "DestinationFacilityId": "DC002", "TransportMode": "Ground", "TravelTimeHours": 17.5},
        {"RouteId": "RT092", "OriginFacilityId": "DC002", "DestinationFacilityId": "DC001", "TransportMode": "Ground", "TravelTimeHours": 17.3},
        {"RouteId": "RT093", "OriginFacilityId": "DC001", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 4.2},
        {"RouteId": "RT094", "OriginFacilityId": "DC003", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 4.1},
        {"RouteId": "RT095", "OriginFacilityId": "DC001", "DestinationFacilityId": "DC004", "TransportMode": "Ground", "TravelTimeHours": 18.0},
        {"RouteId": "RT096", "OriginFacilityId": "DC004", "DestinationFacilityId": "DC001", "TransportMode": "Ground", "TravelTimeHours": 17.8},
        {"RouteId": "RT097", "OriginFacilityId": "DC001", "DestinationFacilityId": "DC005", "TransportMode": "Ground", "TravelTimeHours": 14.0},
        {"RouteId": "RT098", "OriginFacilityId": "DC005", "DestinationFacilityId": "DC001", "TransportMode": "Ground", "TravelTimeHours": 13.8},
        {"RouteId": "RT099", "OriginFacilityId": "DC002", "DestinationFacilityId": "DC003", "TransportMode": "Ground", "TravelTimeHours": 22.5},
        {"RouteId": "RT100", "OriginFacilityId": "DC003", "DestinationFacilityId": "DC002", "TransportMode": "Ground", "TravelTimeHours": 22.3},
        {"RouteId": "RT101", "OriginFacilityId": "DC002", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 2.8},
        {"RouteId": "RT102", "OriginFacilityId": "DC003", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 2.7},
        {"RouteId": "RT103", "OriginFacilityId": "DC002", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 3.4},
        {"RouteId": "RT104", "OriginFacilityId": "DC004", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 3.3},
        {"RouteId": "RT105", "OriginFacilityId": "DC002", "DestinationFacilityId": "DC005", "TransportMode": "Ground", "TravelTimeHours": 24.0},
        {"RouteId": "RT106", "OriginFacilityId": "DC005", "DestinationFacilityId": "DC002", "TransportMode": "Ground", "TravelTimeHours": 23.8},
        {"RouteId": "RT107", "OriginFacilityId": "DC003", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 3.8},
        {"RouteId": "RT108", "OriginFacilityId": "DC004", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 3.7},
        {"RouteId": "RT109", "OriginFacilityId": "DC003", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 3.6},
        {"RouteId": "RT110", "OriginFacilityId": "DC005", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 3.5},
        {"RouteId": "RT111", "OriginFacilityId": "DC004", "DestinationFacilityId": "DC005", "TransportMode": "Ground", "TravelTimeHours": 4.2},
        {"RouteId": "RT112", "OriginFacilityId": "DC005", "DestinationFacilityId": "DC004", "TransportMode": "Ground", "TravelTimeHours": 4.0},

        # Distribution Center to Local routes
        {"RouteId": "RT113", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 3.3},
        {"RouteId": "RT114", "OriginFacilityId": "LC001", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 3.2},
        {"RouteId": "RT115", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 3.0},
        {"RouteId": "RT116", "OriginFacilityId": "LC002", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 2.9},
        {"RouteId": "RT117", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC002", "TransportMode": "Ground", "TravelTimeHours": 28.0},
        {"RouteId": "RT118", "OriginFacilityId": "LC002", "DestinationFacilityId": "DC001", "TransportMode": "Ground", "TravelTimeHours": 27.8},
        {"RouteId": "RT119", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 2.5},
        {"RouteId": "RT120", "OriginFacilityId": "LC003", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 2.4},
        {"RouteId": "RT121", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC003", "TransportMode": "Ground", "TravelTimeHours": 22.0},
        {"RouteId": "RT122", "OriginFacilityId": "LC003", "DestinationFacilityId": "DC001", "TransportMode": "Ground", "TravelTimeHours": 21.8},
        {"RouteId": "RT123", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 3.5},
        {"RouteId": "RT124", "OriginFacilityId": "LC004", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 3.4},
        {"RouteId": "RT125", "OriginFacilityId": "DC001", "DestinationFacilityId": "LC005", "TransportMode": "Air", "TravelTimeHours": 3.6},
        {"RouteId": "RT126", "OriginFacilityId": "LC005", "DestinationFacilityId": "DC001", "TransportMode": "Air", "TravelTimeHours": 3.5},
        {"RouteId": "RT127", "OriginFacilityId": "DC002", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 3.9},
        {"RouteId": "RT128", "OriginFacilityId": "LC001", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 3.8},
        {"RouteId": "RT129", "OriginFacilityId": "DC002", "DestinationFacilityId": "LC002", "TransportMode": "Ground", "TravelTimeHours": 7.0},
        {"RouteId": "RT130", "OriginFacilityId": "LC002", "DestinationFacilityId": "DC002", "TransportMode": "Ground", "TravelTimeHours": 6.8},
        {"RouteId": "RT131", "OriginFacilityId": "DC002", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 3.8},
        {"RouteId": "RT132", "OriginFacilityId": "LC003", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 3.7},
        {"RouteId": "RT133", "OriginFacilityId": "DC002", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 4.2},
        {"RouteId": "RT134", "OriginFacilityId": "LC004", "DestinationFacilityId": "DC002", "TransportMode": "Air", "TravelTimeHours": 4.1},
        {"RouteId": "RT135", "OriginFacilityId": "DC002", "DestinationFacilityId": "LC005", "TransportMode": "Ground", "TravelTimeHours": 12.5},
        {"RouteId": "RT136", "OriginFacilityId": "LC005", "DestinationFacilityId": "DC002", "TransportMode": "Ground", "TravelTimeHours": 12.3},
        {"RouteId": "RT137", "OriginFacilityId": "DC003", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 5.0},
        {"RouteId": "RT138", "OriginFacilityId": "LC001", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 4.9},
        {"RouteId": "RT139", "OriginFacilityId": "DC003", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 2.8},
        {"RouteId": "RT140", "OriginFacilityId": "LC002", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 2.7},
        {"RouteId": "RT141", "OriginFacilityId": "DC003", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 5.8},
        {"RouteId": "RT142", "OriginFacilityId": "LC003", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 5.7},
        {"RouteId": "RT143", "OriginFacilityId": "DC003", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 5.2},
        {"RouteId": "RT144", "OriginFacilityId": "LC004", "DestinationFacilityId": "DC003", "TransportMode": "Air", "TravelTimeHours": 5.1},
        {"RouteId": "RT145", "OriginFacilityId": "DC003", "DestinationFacilityId": "LC005", "TransportMode": "Ground", "TravelTimeHours": 12.5},
        {"RouteId": "RT146", "OriginFacilityId": "LC005", "DestinationFacilityId": "DC003", "TransportMode": "Ground", "TravelTimeHours": 12.3},
        {"RouteId": "RT147", "OriginFacilityId": "DC004", "DestinationFacilityId": "LC001", "TransportMode": "Ground", "TravelTimeHours": 10.0},
        {"RouteId": "RT148", "OriginFacilityId": "LC001", "DestinationFacilityId": "DC004", "TransportMode": "Ground", "TravelTimeHours": 9.8},
        {"RouteId": "RT149", "OriginFacilityId": "DC004", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 4.5},
        {"RouteId": "RT150", "OriginFacilityId": "LC002", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 4.4},
        {"RouteId": "RT151", "OriginFacilityId": "DC004", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 2.4},
        {"RouteId": "RT152", "OriginFacilityId": "LC003", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 2.3},
        {"RouteId": "RT153", "OriginFacilityId": "DC004", "DestinationFacilityId": "LC004", "TransportMode": "Ground", "TravelTimeHours": 12.0},
        {"RouteId": "RT154", "OriginFacilityId": "LC004", "DestinationFacilityId": "DC004", "TransportMode": "Ground", "TravelTimeHours": 11.8},
        {"RouteId": "RT155", "OriginFacilityId": "DC004", "DestinationFacilityId": "LC005", "TransportMode": "Air", "TravelTimeHours": 4.6},
        {"RouteId": "RT156", "OriginFacilityId": "LC005", "DestinationFacilityId": "DC004", "TransportMode": "Air", "TravelTimeHours": 4.5},
        {"RouteId": "RT157", "OriginFacilityId": "DC005", "DestinationFacilityId": "LC001", "TransportMode": "Air", "TravelTimeHours": 1.9},
        {"RouteId": "RT158", "OriginFacilityId": "LC001", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 1.8},
        {"RouteId": "RT159", "OriginFacilityId": "DC005", "DestinationFacilityId": "LC002", "TransportMode": "Air", "TravelTimeHours": 4.3},
        {"RouteId": "RT160", "OriginFacilityId": "LC002", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 4.2},
        {"RouteId": "RT161", "OriginFacilityId": "DC005", "DestinationFacilityId": "LC003", "TransportMode": "Air", "TravelTimeHours": 2.0},
        {"RouteId": "RT162", "OriginFacilityId": "LC003", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 1.9},
        {"RouteId": "RT163", "OriginFacilityId": "DC005", "DestinationFacilityId": "LC004", "TransportMode": "Air", "TravelTimeHours": 1.8},
        {"RouteId": "RT164", "OriginFacilityId": "LC004", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 1.7},
        {"RouteId": "RT165", "OriginFacilityId": "DC005", "DestinationFacilityId": "LC005", "TransportMode": "Air", "TravelTimeHours": 4.4},
        {"RouteId": "RT166", "OriginFacilityId": "LC005", "DestinationFacilityId": "DC005", "TransportMode": "Air", "TravelTimeHours": 4.3}
    ]

    # Define event types
    EVENT_TYPES = [
        "Created", "Received", "Processed", "Departed", "InTransit", "OutForDelivery", 
        "DeliveryAttempted", "Delivered", "Exception", "ExceptionResolved", "Rerouted"
    ]

    # Service levels
    SERVICE_LEVELS = [
        {"level": "Standard", "weight": 60, "days": 4},
        {"level": "Express", "weight": 25, "days": 2},
        {"level": "Priority", "weight": 10, "days": 1},
        {"level": "Freight", "weight": 5, "days": 6}
    ]

    # Exception types
    EXCEPTION_TYPES = [
        {"code": "WEATHER", "severity": "Major", "description": "Weather delay"},
        {"code": "DAMAGED", "severity": "Major", "description": "Package damaged"},
        {"code": "ADDRESS", "severity": "Minor", "description": "Address issue"},
        {"code": "CUSTOMS", "severity": "Major", "description": "Customs delay"},
        {"code": "CAPACITY", "severity": "Minor", "description": "Capacity constraint"},
        {"code": "NOONE", "severity": "Minor", "description": "No one at delivery location"},
        {"code": "VEHICLE", "severity": "Major", "description": "Vehicle breakdown"}
    ]

    # Resolution actions
    RESOLUTION_ACTIONS = ["Reroute", "Repackage", "Delay", "CustomerContact", "ReturnToSender"]

    # Scan devices
    SCAN_DEVICES = ["SCAN001", "SCAN002", "SCAN003", "SCAN004", "SCAN005", "SCAN006", 
                    "MOBILE001", "MOBILE002", "MOBILE003", "SORTER01", "SORTER02", "GPS001"]

    # Employees
    EMPLOYEEs = [f"EMP{i:03d}" for i in range(100, 150)]

    LOCALES = ['en_US','es_ES']

    PHRASES = {
      "pos": {"en_US": ["Arrived on time","Driver was kind","Package intact","Smooth delivery"],
              "es_ES": ["Llegó a tiempo","Repartidor amable","Paquete intacto","Entrega sin problemas"]},
      "neg": {"en_US": ["Late delivery","Box damaged","No update on tracking","Driver left at wrong door"],
              "es_ES": ["Entrega tardía","Caja dañada","Sin actualización de seguimiento","Dejado en la puerta equivocada"]},
      "neu": {"en_US": ["Left at the front gate","Signed at reception","Handed to neighbor"],
              "es_ES": ["Dejado en la puerta","Firmado en recepción","Consegnato al vicino"]},
    }

    PHR_FRIDGE = {
      "pos": ["cold chain ok","bien frío"],
      "neg": ["melted gel pack","hielo derretido"],
      "neu": ["kept cool","mantenido frío"],
    }
    PHR_FRAGILE = {
      "pos": ["careful handling","embalaje firme"],
      "neg": ["cracked glass","caja aplastada"],
      "neu": ["handle with care note","nota frágil"],
    }
    PHR_HAZ = {
      "pos": ["labels correct","etiquetas correctas"],
      "neg": ["missing hazmat label","etiqueta peligrosa ausente"],
      "neu": ["hazmat item","artículo peligroso"],
    }

    # Precompiled typo patterns
    TYPO_PATTERNS = [
      (re.compile(r"\bdelivery\b", re.I), ["delivry","deliveri","delvery"]),
      (re.compile(r"\bdelivered\b", re.I), ["deliverd","delivred"]),
      (re.compile(r"\bpackage\b", re.I), ["pakage","pacakge"]),
      (re.compile(r"\bdriver\b", re.I), ["drvier","dirver"]),
      (re.compile(r"\btracking\b", re.I), ["trackng","trackin"]),
      (re.compile(r"\baddress\b", re.I), ["adress","addres"]),
      (re.compile(r"\btime\b", re.I), ["tiem"]),
      (re.compile(r"\blate\b", re.I), ["la te","l8"]),
    ]

    # Jitter settings by stars
    JITTER = {
      5: dict(typo_p=0.01, excl=(0,1), emojis=["🙂","😊","👍","🙏","✨","⭐"], emo=(0,1)),
      4: dict(typo_p=0.02, excl=(0,1), emojis=["🙂","😊","👍","🙏","✨"],     emo=(0,1)),
      3: dict(typo_p=0.05, excl=(0,2), emojis=["😐","🤔","🙂"],               emo=(0,1)),
      2: dict(typo_p=0.10, excl=(1,3), emojis=["😞","😡","😤","🙄"],           emo=(1,2)),
      1: dict(typo_p=0.15, excl=(1,4), emojis=["🤬","😡","😤","🙄","😠"],       emo=(1,2)),
    }


    def __init__(self, target_folder_uri: str = None):
        self.target_folder_uri = target_folder_uri
        self.SHIP_DIR = Path(posixpath.join(self.target_folder_uri, "shipments"))
        self.EVT_DIR = Path(posixpath.join(self.target_folder_uri, "events"))
        self.SHIP_DIR.mkdir(parents=True, exist_ok=True)
        self.EVT_DIR.mkdir(parents=True, exist_ok=True)
        # Build route lookup for faster access
        self.route_lookup = {}
        for route in self.ROUTES:
            key = f"{route['OriginFacilityId']}_{route['DestinationFacilityId']}"
            self.route_lookup[key] = route

        # Thread control
        self._telemetry_threads = []
        self._telemetry_stop = threading.Event()
        self._telemetry_start_time = None
        self._total_event_count = 0

    def __get_random_coordinate_near(self, lat, lng, radius_miles=10):
        """Generate a random coordinate near a point within specified radius in miles"""
        # 1 degree of latitude is approximately 69 miles
        # 1 degree of longitude varies but at equator is also approximately 69 miles
        radius_lat_deg = radius_miles / 69.0
        radius_lng_deg = radius_miles / (69.0 * np.cos(np.radians(lat)))
        
        random_lat = lat + random.uniform(-radius_lat_deg, radius_lat_deg)
        random_lng = lng + random.uniform(-radius_lng_deg, radius_lng_deg)
        
        return random_lat, random_lng

    def __generate_address_near_facility(self, facility, is_business=False):
        """Generate a realistic address near a facility"""
        lat, lng = self.__get_random_coordinate_near(facility["Latitude"], facility["Longitude"])
        
        if is_business:
            street = fake.street_address() + ", " + fake.company()
        else:
            street = fake.street_address()
        
        return {
            "Address": street,
            "City": facility["City"],
            "State": facility["State"],
            "ZipCode": facility["ZipCode"],
            "Country": "USA",
            "Latitude": lat,
            "Longitude": lng
        }

    def __select_random_weighted(self, options, weight_key="weight"):
        """Select an item randomly with weights"""
        weights = [item[weight_key] for item in options]
        total = sum(weights)
        normalized_weights = [w/total for w in weights]
        return np.random.choice(options, p=normalized_weights)

    def __get_commits(self, service_level, distance_miles):
        """Calculate committed delivery times based on service level and distance"""
        base_days = next((s["days"] for s in self.SERVICE_LEVELS if s["level"] == service_level), 4)
        
        # Adjust based on distance
        if distance_miles < 500:
            days_adjustment = -0.5
        elif distance_miles > 2000:
            days_adjustment = 1
        else:
            days_adjustment = 0
            
        return max(1, base_days + days_adjustment)

    def __haversine_distance(self, lat1, lon1, lat2, lon2):
        """Calculate the great circle distance between two points in miles"""
        lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        miles = 3959 * c  # Radius of earth in miles
        return miles

    def __find_closest_facility(self, lat, lng, facility_type=None):
        """Find the closest facility to a given coordinate"""
        facilities_to_check = self.FACILITIES
        if facility_type:
            facilities_to_check = [f for f in self.FACILITIES if f["FacilityType"] == facility_type]
            
        closest = None
        min_distance = float('inf')
        
        for facility in facilities_to_check:
            distance = self.__haversine_distance(lat, lng, facility["Latitude"], facility["Longitude"])
            if distance < min_distance:
                min_distance = distance
                closest = facility
        
        return closest, min_distance

    def __find_optimal_path(self, origin_facility_id, dest_facility_id):
        """Find a reasonable path from origin to destination"""
        # This is a simplified routing algorithm
        # In a real system, this would use graph algorithms like Dijkstra's
        
        origin_facility = next((f for f in self.FACILITIES if f["FacilityId"] == origin_facility_id), None)
        dest_facility = next((f for f in self.FACILITIES if f["FacilityId"] == dest_facility_id), None)
        
        if not origin_facility or not dest_facility:
            return []
        
        # Direct route if available
        key = f"{origin_facility_id}_{dest_facility_id}"
        if key in self.route_lookup:
            return [{"facility": origin_facility_id, "next": dest_facility_id, "route": self.route_lookup[key]}]
        
        # Try to route via hubs based on region
        path = []
        current = origin_facility_id
        
        # Step 1: If origin is local, try to route to nearest hub
        if origin_facility["FacilityType"] == "Local":
            # Find nearest hub
            hub_facilities = [f for f in self.FACILITIES if f["FacilityType"] == "Hub"]
            nearest_hub = min(hub_facilities, key=lambda h: 
                               self.__haversine_distance(origin_facility["Latitude"], origin_facility["Longitude"], 
                                          h["Latitude"], h["Longitude"]))
            key = f"{current}_{nearest_hub['FacilityId']}"
            if key in self.route_lookup:
                path.append({"facility": current, "next": nearest_hub["FacilityId"], "route": self.route_lookup[key]})
                current = nearest_hub["FacilityId"]
        
        # Step 2: If destination is local, find route to nearest hub
        if dest_facility["FacilityType"] == "Local":
            hub_facilities = [f for f in self.FACILITIES if f["FacilityType"] == "Hub"]
            nearest_dest_hub = min(hub_facilities, key=lambda h: 
                                  self.__haversine_distance(dest_facility["Latitude"], dest_facility["Longitude"], 
                                             h["Latitude"], h["Longitude"]))
            
            # Try to go from current to this hub
            key = f"{current}_{nearest_dest_hub['FacilityId']}"
            if key in self.route_lookup:
                path.append({"facility": current, "next": nearest_dest_hub["FacilityId"], "route": self.route_lookup[key]})
                current = nearest_dest_hub["FacilityId"]
            
            # Then from this hub to destination
            key = f"{current}_{dest_facility_id}"
            if key in self.route_lookup:
                path.append({"facility": current, "next": dest_facility_id, "route": self.route_lookup[key]})
                return path
        
        # Step 3: If still no path, try to use distribution centers
        if not path:
            # Find distribution centers near origin and destination
            dist_facilities = [f for f in self.FACILITIES if f["FacilityType"] == "Distribution"]
            if dist_facilities:
                nearest_origin_dc = min(dist_facilities, key=lambda d: 
                                      self.__haversine_distance(origin_facility["Latitude"], origin_facility["Longitude"], 
                                                 d["Latitude"], d["Longitude"]))
                nearest_dest_dc = min(dist_facilities, key=lambda d: 
                                     self.__haversine_distance(dest_facility["Latitude"], dest_facility["Longitude"], 
                                                d["Latitude"], d["Longitude"]))
                
                # Origin to DC
                key = f"{origin_facility_id}_{nearest_origin_dc['FacilityId']}"
                if key in self.route_lookup:
                    path.append({"facility": origin_facility_id, "next": nearest_origin_dc["FacilityId"], "route": self.route_lookup[key]})
                    current = nearest_origin_dc["FacilityId"]
                
                # DC to DC if needed
                key = f"{current}_{nearest_dest_dc['FacilityId']}"
                if current != nearest_dest_dc["FacilityId"] and key in self.route_lookup:
                    path.append({"facility": current, "next": nearest_dest_dc["FacilityId"], "route": self.route_lookup[key]})
                    current = nearest_dest_dc["FacilityId"]
                
                # DC to destination
                key = f"{current}_{dest_facility_id}"
                if key in self.route_lookup:
                    path.append({"facility": current, "next": dest_facility_id, "route": self.route_lookup[key]})
                    return path
        
        return path

    def __jitter_text(self, text: str, stars: int) -> str:
        cfg = self.JITTER[stars]
        out = text
        # "VERY late" emphasis for low stars
        if stars <= 2 and random.random() < 0.35:
            out = re.sub(r"\blate\b", "VERY late", out, flags=re.I)
        # Typos
        for pat, variants in self.TYPO_PATTERNS:
            if random.random() < cfg["typo_p"]:
                out = pat.sub(random.choice(variants), out, count=1)
        # Exclamations
        n_excl = random.randint(*cfg["excl"])
        if n_excl: out = out.rstrip(". ") + "!"*n_excl
        # Emojis
        n_emo = random.randint(*cfg["emo"])
        if n_emo: out += " " + " ".join(random.choice(cfg["emojis"]) for _ in range(n_emo))
        return out

    def __generate_delivery_feedback(self, shipment):
        row = shipment

        # Choose locale (no Faker needed)
        loc = random.choice(self.LOCALES)

        # Inject a few conditions
        late = random.random() < 0.10
        damaged = random.random() < (0.20 + (0.10 if row["IsFragile"] else 0))
        temp_issue = random.random() < (0.05 if row["RequiresRefrigeration"] else 0.05)

        stars = random.choices([5,4,3,2,1], weights=[45,25,15,10,5])[0]
        if late: stars -= 1
        if damaged: stars -= 1
        if temp_issue: stars -= 1
        stars = max(1, min(5, stars))

        bucket = "pos" if stars >= 4 else ("neg" if stars <= 2 else "neu")
        parts = [random.choice(self.PHRASES[bucket][loc])]

        if row["RequiresRefrigeration"]:
            parts.append(random.choice(self.PHR_FRIDGE[bucket]))
        if row["IsFragile"]:
            parts.append(random.choice(self.PHR_FRAGILE[bucket]))
        if row["IsHazardous"]:
            parts.append(random.choice(self.PHR_HAZ[bucket]))

        return self.__jitter_text(". ".join(p for p in parts if p), stars)

    def _generate_shipment(self):
        """Generate a realistic shipment"""
        # Generate a shipment ID
        shipment_id = f"SHP{str(uuid.uuid4().int)[:8]}"
        tracking_number = f"XYZ{fake.bothify('???#########')}".upper()
        
        # Customer information
        customer_id = f"CUST{random.randint(1000, 9999)}"
        is_business = random.random() < 0.7  # 70% chance of business customer
        if is_business:
            customer_name = fake.company()
        else:
            customer_name = fake.name()
        
        # Select origin and destination facilities
        origin_facility = random.choice(self.FACILITIES)
        
        # Ensure destination is different from origin
        dest_facilities = [f for f in self.FACILITIES if f != origin_facility]
        destination_facility = random.choice(dest_facilities)
        
        # Generate addresses
        origin_address = self.__generate_address_near_facility(origin_facility, is_business)
        destination_address = self.__generate_address_near_facility(destination_facility, is_business=(random.random() < 0.5))
        
        # Calculate approximate distance
        distance = self.__haversine_distance(
            origin_address["Latitude"], origin_address["Longitude"],
            destination_address["Latitude"], destination_address["Longitude"]
        )
        
        # Service level
        service_level_obj = self.__select_random_weighted(self.SERVICE_LEVELS)
        service_level = service_level_obj["level"]
        
        # Dates
        ship_date = datetime.now()
        delivery_days = self.__get_commits(service_level, distance)
        committed_delivery_date = ship_date + timedelta(days=delivery_days)
        
        # Package dimensions - vary by service type
        if service_level == "Freight":
            weight = round(random.uniform(200, 1500), 1)
            length = round(random.uniform(36, 96), 1)
            width = round(random.uniform(24, 48), 1)
            height = round(random.uniform(24, 48), 1)
        elif service_level == "Priority":
            weight = round(random.uniform(2, 30), 1)
            length = round(random.uniform(6, 24), 1)
            width = round(random.uniform(6, 18), 1)
            height = round(random.uniform(2, 12), 1)
        else:
            weight = round(random.uniform(1, 50), 1)
            length = round(random.uniform(4, 36), 1)
            width = round(random.uniform(4, 24), 1)
            height = round(random.uniform(2, 20), 1)
        
        volume = round((length * width * height) / 1728, 2)  # convert to cubic feet
        
        # Value and special handling
        if service_level == "Priority":
            value = round(random.uniform(500, 5000), 2)
        elif service_level == "Freight":
            value = round(random.uniform(1000, 15000), 2)
        else:
            value = round(random.uniform(20, 1000), 2)
        
        is_hazardous = random.random() < 0.05  # 5% chance
        is_fragile = random.random() < 0.15    # 15% chance
        requires_refrigeration = random.random() < 0.08  # 8% chance
        
        # Penalty for late delivery based on value and service level
        if service_level == "Priority":
            penalty = round(value * 0.10, 2)  # 10% of value per day
        elif service_level == "Express":
            penalty = round(value * 0.05, 2)  # 5% of value per day
        elif service_level == "Freight":
            penalty = round(value * 0.03, 2)  # 3% of value per day
        else:
            penalty = round(value * 0.02, 2)  # 2% of value per day
        
        # Special instructions
        instructions = []
        if is_fragile:
            instructions.append("Handle with care")
        if requires_refrigeration:
            temp_min = random.choice([2, 35, 40])
            temp_max = temp_min + random.choice([5, 10, 15])
            temp_unit = "C" if temp_min < 10 else "F"
            instructions.append(f"Temperature controlled {temp_min}-{temp_max}{temp_unit}")
        if weight > 100:
            instructions.append("Team lift required")
        if value > 1000:
            instructions.append("High value package")
        if random.random() < 0.2:
            instructions.append("Signature required")
        
        special_instructions = ", ".join(instructions) if instructions else "None"
        
        # Find closest facilities to origin and destination
        origin_facility, _ = self.__find_closest_facility(origin_address["Latitude"], origin_address["Longitude"], "Local" if random.random() < 0.7 else None)
        destination_facility, _ = self.__find_closest_facility(destination_address["Latitude"], destination_address["Longitude"], "Local" if random.random() < 0.7 else None)
        
        # Generate the shipment
        return {
            "ShipmentId": shipment_id,
            "TrackingNumber": tracking_number,
            "CustomerId": customer_id,
            "CustomerName": customer_name,
            "ServiceLevel": service_level,
            "ShipDate": ship_date.isoformat(),
            "CommittedDeliveryDate": committed_delivery_date.isoformat(),
            
            "OriginAddress": origin_address["Address"],
            "OriginCity": origin_address["City"],
            "OriginState": origin_address["State"],
            "OriginZipCode": origin_address["ZipCode"],
            "OriginCountry": origin_address["Country"],
            "OriginLatitude": origin_address["Latitude"],
            "OriginLongitude": origin_address["Longitude"],
            
            "DestinationAddress": destination_address["Address"],
            "DestinationCity": destination_address["City"],
            "DestinationState": destination_address["State"],
            "DestinationZipCode": destination_address["ZipCode"],
            "DestinationCountry": destination_address["Country"],
            "DestinationLatitude": destination_address["Latitude"],
            "DestinationLongitude": destination_address["Longitude"],
            
            "Weight": weight,
            "Length": length,
            "Width": width,
            "Height": height,
            "Volume": volume,
            "DeclaredValue": value,
            
            "IsHazardous": is_hazardous,
            "IsFragile": is_fragile,
            "RequiresRefrigeration": requires_refrigeration,
            "LateDeliveryPenaltyPerDay": penalty,
            "SpecialInstructions": special_instructions,
            
            "CurrentFacilityId": origin_facility["FacilityId"],
            "OriginFacilityId": origin_facility["FacilityId"],
            "DestinationFacilityId": destination_facility["FacilityId"],
            
            "Distance": distance
        }

    def _generate_shipment_event(self, shipment):
        """Generate a sequence of events for a shipment"""
        events = []
        
        # Starting parameters
        current_time = datetime.fromisoformat(shipment["ShipDate"])
        current_facility = shipment["OriginFacilityId"]
        destination_facility = shipment["DestinationFacilityId"]
        event_id_counter = 1
        
        # Find the planned path
        planned_path = self.__find_optimal_path(current_facility, destination_facility)
        if not planned_path:
            # Fallback if no path found
            planned_path = [{"facility": current_facility, "next": destination_facility, 
            "route": {"RouteId": "DIRECT", "OriginFacilityId": current_facility, "DestinationFacilityId": destination_facility, "TransportMode": "Ground", "TravelTimeHours": 48.0}}]
        
        # Path as facility IDs for the snapshot
        path_snapshot = [leg["facility"] for leg in planned_path] + [destination_facility]
        
        # Create initial event
        events.append({
            "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
            "ShipmentId": shipment["ShipmentId"],
            "TrackingNumber": shipment["TrackingNumber"],
            "EventType": "Created",
            "EventTimestamp": current_time.isoformat(),
            "FacilityId": current_facility,
            "EmployeeId": random.choice(self.EMPLOYEEs),
            "ScanDeviceId": random.choice(self.SCAN_DEVICES),
            "NextWaypointFacilityId": None,
            "RouteId": None,
            "ScheduleId": None,
            "EstimatedArrivalTime": None,
            "ExceptionCode": None,
            "ExceptionSeverity": None,
            "ResolutionAction": None,
            "RelatedExceptionEventId": None,
            "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
            "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
            "SortingEquipmentId": None,
            "SortLaneId": None,
            "AdditionalData": {"method": random.choice(["Online", "API", "Counter", "Phone"])},
            "CurrentServiceLevel": shipment["ServiceLevel"],
            "CurrentOriginFacilityId": shipment["OriginFacilityId"],
            "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
            "PlannedPathSnapshot": path_snapshot
        })
        event_id_counter += 1
        
        # Advance time 30min for shipment receipt
        current_time += timedelta(minutes=random.randint(15, 45))
        events.append({
            "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
            "ShipmentId": shipment["ShipmentId"],
            "TrackingNumber": shipment["TrackingNumber"],
            "EventType": "Received",
            "EventTimestamp": current_time.isoformat(),
            "FacilityId": current_facility,
            "EmployeeId": random.choice(self.EMPLOYEEs),
            "ScanDeviceId": random.choice(self.SCAN_DEVICES),
            "NextWaypointFacilityId": None,
            "RouteId": None,
            "ScheduleId": None,
            "EstimatedArrivalTime": None,
            "ExceptionCode": None,
            "ExceptionSeverity": None,
            "ResolutionAction": None,
            "RelatedExceptionEventId": None,
            "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
            "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
            "SortingEquipmentId": None,
            "SortLaneId": None,
            "AdditionalData": {"condition": "Good"},
            "CurrentServiceLevel": shipment["ServiceLevel"],
            "CurrentOriginFacilityId": shipment["OriginFacilityId"],
            "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
            "PlannedPathSnapshot": path_snapshot
        })
        event_id_counter += 1
        
        # Process through each leg of the journey
        for i, leg in enumerate(planned_path):
            current_facility = leg["facility"]
            next_facility = leg["next"]
            route = leg["route"]
            
            # Randomize exception occurrence (5% chance for normal shipments)
            exception_occurred = random.random() < 0.05 + (0.1 if shipment["IsHazardous"] else 0)
            
            if not exception_occurred:
                # Normal processing flow
                
                # Sort decision - adds 30-90 min
                current_time += timedelta(minutes=random.randint(30, 90))
                schedule_id = f"SCH{random.randint(1000, 9999)}"
                arrival_estimate = current_time + timedelta(hours=route["TravelTimeHours"])
                
                events.append({
                    "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Processed",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SORTER" in d]),
                    "NextWaypointFacilityId": next_facility,
                    "RouteId": route["RouteId"],
                    "ScheduleId": schedule_id,
                    "EstimatedArrivalTime": arrival_estimate.isoformat(),
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": random.choice(["SORT01", "SORT02", "SORT03"]),
                    "SortLaneId": f"LANE{random.randint(1, 20):02d}",
                    "AdditionalData": {"sortDecision": "Optimal route" if i == 0 else "Continuing on route"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Departure - adds 1-3 hours
                current_time += timedelta(hours=random.randint(1, 3))
                events.append({
                    "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Departed",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": next_facility,
                    "RouteId": route["RouteId"],
                    "ScheduleId": schedule_id,
                    "EstimatedArrivalTime": arrival_estimate.isoformat(),
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {
                        "loadId": f"LD{random.randint(1000, 9999)}"
                        #"transportType": "Flight" if route["TransportMode"] == "Air" else "Truck"
                    },
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Possible in-transit GPS updates for longer routes
                if route["TravelTimeHours"] > 4:
                    # Number of updates based on journey length
                    num_updates = min(int(route["TravelTimeHours"] / 4), 5)
                    for _ in range(num_updates):
                        current_time += timedelta(hours=route["TravelTimeHours"] / (num_updates + 1))
                        
                        # Calculate a point along the route
                        origin_lat = next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), 0)
                        origin_lng = next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), 0)
                        dest_lat = next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == next_facility), 0)
                        dest_lng = next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == next_facility), 0)
                        
                        # Simple linear interpolation
                        progress = (_ + 1) / (num_updates + 1)
                        current_lat = origin_lat + (dest_lat - origin_lat) * progress
                        current_lng = origin_lng + (dest_lng - origin_lng) * progress
                        
                        # Add some random noise
                        current_lat += random.uniform(-0.05, 0.05)
                        current_lng += random.uniform(-0.05, 0.05)
                        
                        events.append({
                            "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                            "ShipmentId": shipment["ShipmentId"],
                            "TrackingNumber": shipment["TrackingNumber"],
                            "EventType": "InTransit",
                            "EventTimestamp": current_time.isoformat(),
                            "FacilityId": None,
                            "EmployeeId": "SYSTEM",
                            "ScanDeviceId": "GPS001",
                            "NextWaypointFacilityId": next_facility,
                            "RouteId": route["RouteId"],
                            "ScheduleId": schedule_id,
                            "EstimatedArrivalTime": arrival_estimate.isoformat(),
                            "ExceptionCode": None,
                            "ExceptionSeverity": None,
                            "ResolutionAction": None,
                            "RelatedExceptionEventId": None,
                            "LocationLatitude": current_lat,
                            "LocationLongitude": current_lng,
                            "SortingEquipmentId": None,
                            "SortLaneId": None,
                            "AdditionalData": {
                                "vehicleId": f"{'FLIGHT' if route['TransportMode']=='Air' else 'TRUCK'}{random.randint(100, 999)}"
                            },
                            "CurrentServiceLevel": shipment["ServiceLevel"],
                            "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                            "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                            "PlannedPathSnapshot": path_snapshot
                        })
                        event_id_counter += 1
                
                # Arrival at next facility - add the travel time with some variance
                travel_variance = random.uniform(0.85, 1.15)  # +/- 15%
                current_time += timedelta(hours=route["TravelTimeHours"] * travel_variance) - timedelta(hours=route["TravelTimeHours"] / (num_updates + 1) * num_updates if route["TravelTimeHours"] > 4 else 0)
                
                # Update the current facility
                current_facility = next_facility
                
                # Receipt at next facility
                events.append({
                    "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Received",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"condition": "Good"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
            
            else:
                # Handle exception case
                current_time += timedelta(minutes=random.randint(30, 90))
                exception = random.choice(self.EXCEPTION_TYPES)
                exception_event_id = f"EVT{shipment['ShipmentId']}{event_id_counter:04d}"
                
                events.append({
                    "EventId": exception_event_id,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Exception",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": exception["code"],
                    "ExceptionSeverity": exception["severity"],
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"reason": exception["description"]},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Add time for resolution
                current_time += timedelta(hours=random.randint(1, 8))
                resolution_action = random.choice(self.RESOLUTION_ACTIONS)
                
                events.append({
                    "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "ExceptionResolved",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": resolution_action,
                    "RelatedExceptionEventId": exception_event_id,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"resolution": f"{resolution_action} completed"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # If the exception impacts routing, we may need to adjust the path
                if resolution_action == "Reroute":
                    # Maybe we need to insert a different destination facility
                    # Simplified for now - just proceed with the original path
                    events.append({
                        "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                        "ShipmentId": shipment["ShipmentId"],
                        "TrackingNumber": shipment["TrackingNumber"],
                        "EventType": "Rerouted",
                        "EventTimestamp": current_time.isoformat(),
                        "FacilityId": current_facility,
                        "EmployeeId": random.choice(self.EMPLOYEEs),
                        "ScanDeviceId": "SYSTEM",
                        "NextWaypointFacilityId": next_facility,
                        "RouteId": route["RouteId"],
                        "ScheduleId": f"SCH{random.randint(1000, 9999)}",
                        "EstimatedArrivalTime": (current_time + timedelta(hours=route["TravelTimeHours"])).isoformat(),
                        "ExceptionCode": None,
                        "ExceptionSeverity": None,
                        "ResolutionAction": None,
                        "RelatedExceptionEventId": None,
                        "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                        "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                        "SortingEquipmentId": None,
                        "SortLaneId": None,
                        "AdditionalData": {"reroute": "Path resumed after exception"},
                        "CurrentServiceLevel": shipment["ServiceLevel"],
                        "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                        "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                        "PlannedPathSnapshot": path_snapshot
                    })
                    event_id_counter += 1
                    
                # Continue with departure and receipt as in normal flow
                current_time += timedelta(hours=random.randint(1, 3))
                schedule_id = f"SCH{random.randint(1000, 9999)}"
                arrival_estimate = current_time + timedelta(hours=route["TravelTimeHours"])
                
                events.append({
                    "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Departed",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": next_facility,
                    "RouteId": route["RouteId"],
                    "ScheduleId": schedule_id,
                    "EstimatedArrivalTime": arrival_estimate.isoformat(),
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {
                        "loadId": f"LD{random.randint(1000, 9999)}",
                        "transportType": "Flight" if route["TransportMode"] == "Air" else "Truck"
                    },
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
                
                # Update the current facility after travel
                travel_variance = random.uniform(0.85, 1.15)  # +/- 15%
                current_time += timedelta(hours=route["TravelTimeHours"] * travel_variance)
                current_facility = next_facility
                
                # Receipt at next facility
                events.append({
                    "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "Received",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "SCAN" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": None,
                    "ExceptionSeverity": None,
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"condition": "Good"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot
                })
                event_id_counter += 1
        
        # Add final delivery events if we've gone through all legs and reached the final facility
        if current_facility == destination_facility:
            # Out for delivery
            current_time += timedelta(hours=random.randint(1, 4))
            events.append({
                "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                "ShipmentId": shipment["ShipmentId"],
                "TrackingNumber": shipment["TrackingNumber"],
                "EventType": "OutForDelivery",
                "EventTimestamp": current_time.isoformat(),
                "FacilityId": current_facility,
                "EmployeeId": random.choice(self.EMPLOYEEs),
                "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "MOBILE" in d]),
                "NextWaypointFacilityId": None,
                "RouteId": None,
                "ScheduleId": None,
                "EstimatedArrivalTime": None,
                "ExceptionCode": None,
                "ExceptionSeverity": None,
                "ResolutionAction": None,
                "RelatedExceptionEventId": None,
                "LocationLatitude": next((f["Latitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                "LocationLongitude": next((f["Longitude"] for f in self.FACILITIES if f["FacilityId"] == current_facility), None),
                "SortingEquipmentId": None,
                "SortLaneId": None,
                "AdditionalData": {"vehicleId": f"VAN{random.randint(100, 999)}", "stopSequence": random.randint(1, 30)},
                "CurrentServiceLevel": shipment["ServiceLevel"],
                "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                "PlannedPathSnapshot": path_snapshot + ["CUSTOMER"]
            })
            event_id_counter += 1
            
            # Possible delivery exception (10% chance)
            delivery_exception = random.random() < 0.1
            if delivery_exception:
                current_time += timedelta(hours=random.randint(2, 6))
                exception_event_id = f"EVT{shipment['ShipmentId']}{event_id_counter:04d}"
                
                events.append({
                    "EventId": exception_event_id,
                    "ShipmentId": shipment["ShipmentId"],
                    "TrackingNumber": shipment["TrackingNumber"],
                    "EventType": "DeliveryAttempted",
                    "EventTimestamp": current_time.isoformat(),
                    "FacilityId": current_facility,
                    "EmployeeId": random.choice(self.EMPLOYEEs),
                    "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "MOBILE" in d]),
                    "NextWaypointFacilityId": None,
                    "RouteId": None,
                    "ScheduleId": None,
                    "EstimatedArrivalTime": None,
                    "ExceptionCode": "NOONE",
                    "ExceptionSeverity": "Minor",
                    "ResolutionAction": None,
                    "RelatedExceptionEventId": None,
                    "LocationLatitude": shipment["DestinationLatitude"],
                    "LocationLongitude": shipment["DestinationLongitude"],
                    "SortingEquipmentId": None,
                    "SortLaneId": None,
                    "AdditionalData": {"note": "No one at delivery address"},
                    "CurrentServiceLevel": shipment["ServiceLevel"],
                    "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                    "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                    "PlannedPathSnapshot": path_snapshot + ["CUSTOMER"]
                })
                event_id_counter += 1
                
                # Next delivery attempt
                current_time += timedelta(hours=random.randint(1, 4))
            else:
                # Normal delivery flow
                current_time += timedelta(hours=random.randint(1, 6))
            
            # Delivered
            events.append({
                "EventId": f"EVT{shipment['ShipmentId']}{event_id_counter:04d}",
                "ShipmentId": shipment["ShipmentId"],
                "TrackingNumber": shipment["TrackingNumber"],
                "EventType": "Delivered",
                "EventTimestamp": current_time.isoformat(),
                "FacilityId": current_facility,
                "EmployeeId": random.choice(self.EMPLOYEEs),
                "ScanDeviceId": random.choice([d for d in self.SCAN_DEVICES if "MOBILE" in d]),
                "NextWaypointFacilityId": None,
                "RouteId": None,
                "ScheduleId": None,
                "EstimatedArrivalTime": None,
                "ExceptionCode": None,
                "ExceptionSeverity": None,
                "ResolutionAction": None,
                "RelatedExceptionEventId": None,
                "LocationLatitude": shipment["DestinationLatitude"],
                "LocationLongitude": shipment["DestinationLongitude"],
                "SortingEquipmentId": None,
                "SortLaneId": None,
                "AdditionalData": {
                    "signedBy": fake.name() if random.random() < 0.7 else "", 
                    "review": self.__generate_delivery_feedback(shipment) if random.random() < 0.6 else ""
                    },
                "CurrentServiceLevel": shipment["ServiceLevel"],
                "CurrentOriginFacilityId": shipment["OriginFacilityId"],
                "CurrentDestinationFacilityId": shipment["DestinationFacilityId"],
                "PlannedPathSnapshot": []
            })
        
        return events
    
    def __now_utc_iso(self):
        return datetime.now(timezone.utc).isoformat()

    def __write_json_file(self, base_dir: Path, filename: str, data: list, record_type: str):
        """Write a list of dicts to one JSON file with a header."""
        payload = {
            "_meta": {
                "schemaVersion": "1.0",
                "producer": "telemetry-sim",
                "recordType": record_type,
                "enqueuedTime": self.__now_utc_iso()
            },
            "data": data
        }
        path = base_dir / filename
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return path
    
    def _start_generator_thread(self, verbose=True):
        """Worker function to send telemetry until stop event is set."""
        total_event_count = 0
        start_time = time.time()

        try:
            if verbose:
                print(f"[{threading.current_thread().name}] Starting generator thread...")
                print(f"[{threading.current_thread().name}] Stop event is set: {self._telemetry_stop.is_set()}")
            
            while not self._telemetry_stop.is_set():
                shipment_buffer, event_buffer = [], []

                # create a random batch
                for _ in range(1, random.randint(10, 50)):
                    shipment = self._generate_shipment()
                    shipment_events = self._generate_shipment_event(shipment)

                    shipment_buffer.append(shipment)
                    event_buffer.extend(shipment_events)

                ts = int(time.time() * 1000)
                ship_file = f"shipments_{ts}.json"
                evt_file  = f"events_{ts}.json"

                # --- file writes with header ---
                self.__write_json_file(self.SHIP_DIR, ship_file, shipment_buffer, record_type="shipment")
                self.__write_json_file(self.EVT_DIR, evt_file, event_buffer, record_type="event")

                batch_event_count = len(event_buffer)
                total_event_count += batch_event_count
                self._total_event_count += batch_event_count  # Update instance variable
                elapsed_time = time.time() - start_time
                eps = total_event_count / elapsed_time if elapsed_time > 0 else 0

                if verbose:
                    print(f"[{threading.current_thread().name}] "
                          f"Wrote {len(shipment_buffer)} shipments & {batch_event_count} events. "
                          f"Total events: {total_event_count}. EPS: {eps:.2f}")
        except Exception as e:
            print(f"[{threading.current_thread().name}] ERROR: {e}")
            import traceback
            traceback.print_exc()
        finally:
            elapsed_time = time.time() - start_time
            eps = total_event_count / elapsed_time if elapsed_time > 0 else 0
            return total_event_count, eps
        
    def start(self, concurrency=2, verbose=True, background=True):
        """
        Start telemetry producer.
        
        Args:
            concurrency: Number of concurrent worker threads
            verbose: Print progress messages
            background: If True, run in background thread. If False, block until interrupted.
        
        Returns:
            (total_events, total_eps) if background=False, otherwise None
        """
        if self._telemetry_threads and any(t.is_alive() for t in self._telemetry_threads):
            print("Generator already running.")
            return
    
        # Clear stop event for new run
        self._telemetry_stop.clear()
        self._total_event_count = 0  # Reset counter
        self._telemetry_start_time = time.time()  # Record start time
    
        def _runner():
            try:
                results = []
                start_time = time.time()
    
                with ThreadPoolExecutor(max_workers=concurrency) as executor:
                    futures = [executor.submit(self._start_generator_thread, verbose) for _ in range(concurrency)]
                    try:
                        for future in as_completed(futures):
                            results.append(future.result())
                    except KeyboardInterrupt:
                        print("Background thread received interrupt. Stopping all workers...")
                        self._telemetry_stop.set()
                        for future in futures:
                            try:
                                results.append(future.result())
                            except Exception as e:
                                print(f"Thread terminated with error: {e}")
    
                total_events = sum(r[0] for r in results) if results else 0
                total_elapsed = time.time() - start_time
                total_eps = total_events / total_elapsed if total_elapsed > 0 else 0
                print(f"[Runner] exited: total_events={total_events}, eps={total_eps:.2f}")
            except Exception as e:
                print(f"[Runner] error: {e}")
        
        if background:
            # Run in background thread
            thread = threading.Thread(target=_runner, name="Runner", daemon=False)
            thread.start()
            self._telemetry_threads = [thread]
            print(f"Generator started in background with {concurrency} concurrent worker(s).")
            print("Call gen.stop() to stop generation.")
        else:
            # Run in foreground (blocking)
            print(f"Generator starting with {concurrency} concurrent worker(s).")
            print("Interrupt the process to stop generation.")
            
            _runner()
    
    def stop(self, timeout=10):
        """Signal the background producer to stop and join all threads."""
        if not self._telemetry_threads:
            print("Generator not running.")
            return
        
        print("Stopping generator...")
        self._telemetry_stop.set()
        
        for thread in self._telemetry_threads:
            thread.join(timeout=timeout)
            if thread.is_alive():
                print(f"Thread {thread.name} is taking longer to stop; it will exit after the current batch.")
        
        if not any(t.is_alive() for t in self._telemetry_threads):
            print("Generator stopped.")
        
        self._telemetry_threads = []
    
    def status(self):
        """Check if telemetry is currently running and print metrics."""
        is_running = bool(self._telemetry_threads) and any(t.is_alive() for t in self._telemetry_threads)
        
        if is_running:
            elapsed_time = time.time() - self._telemetry_start_time if self._telemetry_start_time else 0
            eps = self._total_event_count / elapsed_time if elapsed_time > 0 else 0
            print(f"Generator running: total_events={self._total_event_count}, eps={eps:.2f}, elapsed={elapsed_time:.1f}s")
        else:
            print("Generator not running.")
        
        return is_running