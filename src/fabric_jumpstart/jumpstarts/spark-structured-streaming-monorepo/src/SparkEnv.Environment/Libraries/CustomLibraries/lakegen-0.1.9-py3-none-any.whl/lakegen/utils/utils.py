def to_unix_path(path_str) -> str:
    # Handle Windows drive letters and backslashes
    result = path_str.replace('\\', '/')
    
    # Remove Windows drive letters (C:, D:, etc.)
    if len(result) >= 2 and result[1] == ':':
        result = result[2:]
    
    # Ensure it starts with '/'
    if not result.startswith('/'):
        result = '/' + result
        
    return result

def detect_runtime() -> str:
        """
        Dynamically detect the runtime/environment.
        Returns: str - The detected service name
        """
        import os    

        # Check for Microsoft Fabric or Synapse
        try:
            notebookutils = get_ipython().user_ns.get("notebookutils")  # noqa: F821
            if notebookutils and hasattr(notebookutils, 'runtime'):
                if hasattr(notebookutils.runtime, 'context'):
                    context = notebookutils.runtime.context
                    if 'productType' in context:
                        product = context['productType'].lower()
                        return product
        except:  # noqa: E722
            pass
        
        # Check for Databricks
        try:
            if 'DATABRICKS_RUNTIME_VERSION' in os.environ:
                return "databricks"
            try:
                dbutils = get_ipython().user_ns.get("dbutils")  # noqa: F821
                if dbutils:
                    return "databricks"
            except:  # noqa: E722
                pass
        except:  # noqa: E722
            pass
        
        # Check for Google Colab
        try:
            if 'COLAB_RELEASE_TAG' in os.environ:
                return "colab"
        except ImportError:
            pass
        
        # Default fallback
        return "local_unknown"